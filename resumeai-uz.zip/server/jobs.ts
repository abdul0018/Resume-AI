import { JobVacancy } from "../src/types";

// Curated active Uzbekistan job database covering various roles, salaries (in Soum or USD), location, and contacts.
export const UZ_VACANCIES: JobVacancy[] = [
  {
    id: "job-1",
    title: "Junior Frontend Developer (React)",
    company: "UzPay Systems LLC",
    salary: "6,000,000 - 9,000,000 UZS",
    location: "Tashkent",
    category: "IT",
    description: "Fintech to'lov tizimi uchun foydalanuvchi interfeyslarini integratsiya qilish va optimallashtirish bilan shug'ullanadigan React mutaxassisi kerak.",
    requirements: [
      "JavaScript, CSS, React.js bo'yicha kamida 1 yillik tajriba",
      "Git tizimi bilan ishlay olish ko'nikmasi",
      "API integratsiyasi borasida boshlang'ich tushuncha"
    ],
    contact: "@uzpay_recruiter",
    postedAt: "2026-05-26"
  },
  {
    id: "job-2",
    title: "Katta Sotuvchi Konsultant (Sales Consultant)",
    company: "Oasis Fashion Group",
    salary: "4,500,000 - 7,000,000 UZS",
    location: "Tashkent",
    category: "sales",
    description: "Kiyim-kechak brend do'koniga mijozlar bilan tushunarli muloqot qiladigan, sotuv rejasini dadil bajaradigan xodim taklif qilinadi.",
    requirements: [
      "O'zbek va rus tillarida erkin so'zlasha olish",
      "Muloqotga kirishuvchanlik va xushmuomalalik",
      "Sotuv sohasida kamida 6 oylik tajriba afzallik beradi"
    ],
    contact: "@oasis_fashion_hr",
    postedAt: "2026-05-27"
  },
  {
    id: "job-3",
    title: "Ingliz tili o'qituvchisi (IELTS Teacher)",
    company: "Everest Education Center",
    salary: "8,000,000 - 15,000,000 UZS",
    location: "Samarkand",
    category: "teacher",
    description: "O'quvchilarni IELTS imtihoniga tayyorlaydigan tajribali, energiyaga to'la o'qituvchi. Do'stona qat'iy jamoa taklif etamiz.",
    requirements: [
      "IELTS balli kamida 7.5 yoki undan yuqori bo'lishi",
      "Bollarni oshirishga yo'naltirilgan o'qitish metodologiyasi",
      "Kamida 1 yillik dars berish tajribasi"
    ],
    contact: "@everest_sam_hr",
    postedAt: "2026-05-25"
  },
  {
    id: "job-4",
    title: "Logistika Menejeri (Yandex Delivery)",
    company: "Sardor Express Delivery",
    salary: "5,000,000 - 8,000,000 UZS",
    location: "Tashkent",
    category: "office",
    description: "Yetkazib berish xizmatida kuryerlar faoliyatini muvofiqlashtirish va mijozlar buyurtmalarini nazorat qilish uchun menejer lavozimi.",
    requirements: [
      "Kompyuter dasturlari va Excel-da tez ishlay olish",
      "Toshkent shahri xaritasini yaxshi bilish",
      "Stressga chidamlilik va tezkor qaror qabul qilish"
    ],
    contact: "@sardor_hr_express",
    postedAt: "2026-05-24"
  },
  {
    id: "job-5",
    title: "Haydovchi (B va C toifalari bilan)",
    company: "Eko-Polimer MCHJ",
    salary: "4,000,000 - 5,500,000 UZS",
    location: "Samarkand",
    category: "driver",
    description: "Kompaniya yuklarini belgilangan manzillarga xavfsiz yetkazib beruvchi professional haydovchi qidirilmoqda.",
    requirements: [
      "B va C haydovchilik guvohnomasining mavjudligi",
      "Kamida 3 yillik tasdiqlangan haydovchilik staji",
      "Texnik nosozliklarni kichik darajada bartaraf eta olish malakasi"
    ],
    contact: "@ekopolimer_logistics",
    postedAt: "2026-05-26"
  },
  {
    id: "job-6",
    title: "SMM Mutaxassisi (SMM Manager)",
    company: "Apex Media Agency",
    salary: "5,000,000 - 10,000,000 UZS",
    location: "remote",
    category: "IT",
    description: "Instagram va Telegram kanallarini yuritish, kreativ g'oyalar berish va mobilografiya bilan band bo'ladigan SMM menejer.",
    requirements: [
      "Portfolio mavjudligi (ish namunalari majburiy)",
      "CapCut va Canva dasturlarida erkin montaj qilish",
      "Targeting reklamasidan boshlang'ich bilimlar"
    ],
    contact: "@apex_media_ceo",
    postedAt: "2026-05-27"
  },
  {
    id: "job-7",
    title: "Mijozlarni Qo'llab-quvvatlash Operator (Support Operator)",
    company: "Beeline Uzbekistan Partner",
    salary: "3,500,000 - 5,000,000 UZS",
    location: "Tashkent",
    category: "office",
    description: "Inbound (kiruvchi) qo'ng'iroqlarga javob berish va mijozlar so'rovlariga tezlikda rasmiy yordam taqdim etish.",
    requirements: [
      "Nutqi ravon va xushovoz bo'lishi",
      "Rus va O'zbek tillarini mukammal bilish jozibasi",
      "Tungi smenada ishlash imkoniyati"
    ],
    contact: "@beeline_partner_recruits",
    postedAt: "2026-05-23"
  },
  {
    id: "job-8",
    title: "Distribyutor (Savdo Agent)",
    company: "Imon Shokoladlari",
    salary: "5,000,000 - 12,000,000 UZS",
    location: "Samarkand",
    category: "sales",
    description: "Samarqand viloyatidagi do'konlar bilan savdolarni kelishish va yangi chakana nuqtalar qamrovini kengaytirish vazifasi.",
    requirements: [
      "Muzokaralar olib borish va mijozlarni qiziqtirish qobiliyati",
      "Shaxsiy avtomobil mavjudligi afzallikdir",
      "Savdoda natija va foizlarga qarab ishlash istagi"
    ],
    contact: "@imon_distribution_hr",
    postedAt: "2026-05-25"
  }
];

export function getFilteredJobs(category?: string, location?: string): JobVacancy[] {
  return UZ_VACANCIES.filter(job => {
    let matchCat = true;
    let matchLoc = true;
    if (category && category.toLowerCase() !== "all") {
      matchCat = job.category.toLowerCase() === category.toLowerCase();
    }
    if (location && location.toLowerCase() !== "all") {
      matchLoc = job.location.toLowerCase() === location.toLowerCase();
    }
    return matchCat && matchLoc;
  });
}
