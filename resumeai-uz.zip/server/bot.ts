import { generateAICV, improveAICV, generateAICoverLetter, generateAIInterviewPrep } from "./ai";
import { getFilteredJobs } from "./jobs";
import { CVData } from "../src/types";

// User Session Structure in memory
export interface UserSession {
  userId: string;
  username: string;
  lang: 'uz' | 'en';
  state: 'IDLE' | 'CREATING_CV_NAME' | 'CREATING_CV_PHONE' | 'CREATING_CV_EDUCATION' | 'CREATING_CV_SKILLS' | 'CREATING_CV_EXPERIENCE' | 'CREATING_CV_LANG' | 'CREATING_CV_DESIGN' | 'CREATING_CV_COLOR' | 'IMPROVING_CV' | 'COVER_LETTER_DESC';
  cvDraft: Partial<CVData>;
  isPremium: boolean;
}

// Global sessions lookup
const sessions: Record<string, UserSession> = {};

// CV shared store for short download links
export const cvStore: Record<string, CVData> = {};

// Helper to save CV and return ID
export function saveCvToStore(cv: CVData): string {
  const shortId = Math.random().toString(36).substring(2, 10);
  cvStore[shortId] = cv;
  return shortId;
}

export function getOrCreateSession(userId: string, username = "JobSeeker"): UserSession {
  if (!sessions[userId]) {
    sessions[userId] = {
      userId,
      username,
      lang: 'uz',
      state: 'IDLE',
      cvDraft: {},
      isPremium: false,
    };
  }
  return sessions[userId];
}

interface BotResponse {
  text: string;
  replyKeyboard?: any[][];
  inlineKeyboard?: { text: string; callbackData: string }[][];
  documentUrl?: string; // If a CV PDF is ready
  cvData?: CVData;      // Attached if CV generation is successfully finalized
}

export async function processBotMessage(userId: string, username: string, textStr: string): Promise<BotResponse> {
  const session = getOrCreateSession(userId, username);
  const text = textStr.trim();

  // Handle global slash commands
  if (text.startsWith('/start')) {
    session.state = 'IDLE';
    session.cvDraft = {};
    return showMainMenu(session, `Asalomu alaykum, ${username || 'foydalanuvchi'}! 🌍\n"ResumeAI UZ" - O'zbekistondagi birinchi professional AI rezyume yaratiuvchi va ish topish yordamchisiga xush kelibsiz!\n\nPastdagi tugmalardan birini tanlang va tezkor ko'makdan foydalaning!`);
  }

  if (text.startsWith('/premium')) {
    return showPremiumMenu(session);
  }

  // --- MAIN MENU OPTION STEERING ---
  if (session.state === 'IDLE') {
    switch (text) {
      case '📄 Yangi CV yaratish (AI)':
        session.state = 'CREATING_CV_NAME';
        session.cvDraft = { skills: [], experience: [], languages: [] };
        return {
          text: "Keling, professional tilda rezyume yaratamiz! 📝\n\nIsm va familiyangizni kiriting:\n*(Masalan: Jasur Alimov)*",
          replyKeyboard: [['❌ Bekor qilish']]
        };

      case '✨ CVni yaxshilash (AI)':
        session.state = 'IMPROVING_CV';
        return {
          text: "Mavjud rezyume matnini yoki o'zingiz haqingizda qisqacha ma'lumotni yuboring 📝\n\nAI tahlil qiladi, grammatikani tuzatadi va eng jozibador formatga o'tkazadi (Ideal 'Before vs After' natijasi).",
          replyKeyboard: [['❌ Bekor qilish']]
        };

      case "💼 Bo'sh ish o'rinlari":
      case "💼 Ishlar ro'yxati":
        return {
          text: "🏢 **Ishlar ro'yxati va eng so'nggi bo'sh ish o'rinlari:**\n\nBarcha faol vakansiyalar va yangi ish e'lonlarini to'g'ridan-to'g'ri bizning hamkor Telegram kanalimizda kuzatib borishingiz mumkin!\n\n🔗 Kanalga o'tish: https://t.me/bobo_vakansiya",
          replyKeyboard: getMainMenuButtons(session)
        };

      case '💡 Suhbatga tayyorgarlik':
        return showInterviewJobSelection();

      case '✉️ Kuzatuv xati (AI Cover Letter)':
        session.state = 'COVER_LETTER_DESC';
        return {
          text: "Siz topshirmoqchi bo'lgan vakansiya ta'rifini ('Job description') yoki lavozim nomini kiriting:\n*(Masalan: Tashkentdagi Apex Group SMM menejeri)*",
          replyKeyboard: [['❌ Bekor qilish']]
        };

      case '💳 Premium & To\'lov':
        return showPremiumMenu(session);

      case '🇺🇿/🇬🇧 Tilni almashtirish':
        session.lang = session.lang === 'uz' ? 'en' : 'uz';
        const msg = session.lang === 'uz' 
          ? "Til O'zbek tiliga muvaffaqiyatli almashtirildi!" 
          : "Language switched to English!";
        return showMainMenu(session, msg);

      default:
        // Handle categories or direct inputs from dynamic keyboard options
        if (text.startsWith('VAK_')) {
          return handleVacanciesFilter(text);
        }
        if (text.startsWith('EXP_')) {
          return handleInterviewPrepSelection(text);
        }
        if (text === '❌ Bekor qilish') {
          session.state = 'IDLE';
          return showMainMenu(session, "Amaliyot bekor qilindi. Bosh sahifa.");
        }
    }
  }

  // --- STATE-SPECIFIC INPUT HANDLERS ---

  // Cancel Handler within states
  if (text === '❌ Bekor qilish') {
    session.state = 'IDLE';
    session.cvDraft = {};
    return showMainMenu(session, "Jarayon bekor qilindi. Bosh menyuga qaytdingiz.");
  }

  // 1. CV Creation State Machine
  if (session.state === 'CREATING_CV_NAME') {
    session.cvDraft.fullName = text;
    session.state = 'CREATING_CV_PHONE';
    return {
      text: "Ajoyib! Endi bog'lanish uchun telefon raqamingizni kiriting:\n*(Masalan: +998 90 123-45-67)*",
      replyKeyboard: [['❌ Bekor qilish']]
    };
  }

  if (session.state === 'CREATING_CV_PHONE') {
    session.cvDraft.phone = text;
    session.state = 'CREATING_CV_EDUCATION';
    return {
      text: "Ma'lumotingiz haqida yozing (Muassasa nomi, yo'nalish, yo'li):\n*(Masalan: TATU, Axborot xavfsizligi, bakalavr, 2024)*",
      replyKeyboard: [['❌ Bekor qilish']]
    };
  }

  if (session.state === 'CREATING_CV_EDUCATION') {
    session.cvDraft.education = text;
    session.state = 'CREATING_CV_SKILLS';
    return {
      text: "Texnik yoki amaliy ko'nikmalaringizni kiriting (bir nechta bo'lsa vergul bilan ajrating):\n*(Masalan: React, JavaScript, Figma, Sotuv psixologiyasi, Excel)*",
      replyKeyboard: [['❌ Bekor qilish']]
    };
  }

  if (session.state === 'CREATING_CV_SKILLS') {
    session.cvDraft.skills = text.split(',').map(s => s.trim());
    session.state = 'CREATING_CV_EXPERIENCE';
    return {
      text: "Ish tajribangiz bormi? Lavozimingiz va kompaniya nomini qisqacha kiriting (agar yo'q bo'lsa 'Yo'q' deb yozing):\n*(Masalan: UzTech do'koni sotuvchisi, 1.5 yil yoki Yo'q)*",
      replyKeyboard: [["Yo'q"], ['❌ Bekor qilish']]
    };
  }

  if (session.state === 'CREATING_CV_EXPERIENCE') {
    if (text.toLowerCase() !== 'yo\'q') {
      session.cvDraft.experience = [
        {
          company: text,
          position: "Mutaxassis",
          duration: "So'nggi yillarda",
          description: "Mijozlar bilan hamkorlik qilish va vazifalarni o'z vaqtida bajarish."
        }
      ];
    } else {
      session.cvDraft.experience = [];
    }
    session.state = 'CREATING_CV_LANG';
    return {
      text: "Chet tillarini bilish darajangizni kiriting:\n*(Masalan: Inglizcha oilaviy, Ruscha o'rtacha yoki O'zbek tili mukammal)*",
      replyKeyboard: [['❌ Bekor qilish']]
    };
  }

  if (session.state === 'CREATING_CV_LANG') {
    session.cvDraft.languages = [
      { language: text, level: "Tasdiqlangan" }
    ];
    session.state = 'CREATING_CV_DESIGN';
    return {
      text: "Deyarli tayyor! 🎨 Rezyumeingizning dizayn shablonini (Design layout style like rezyume.uz) tanlang:\n\n" + 
            "1. 🔵 **Classic** - Standart sodda xalqaro ATS formati.\n" +
            "2. 🟢 **Modern** - Chap qismida rangdor hoshiya bo'lgan zamonaviy dizayn.\n" +
            "3. 🔴 **Creative** - Sarlavhasi rangli va yumaloq rasmli jozibador premium dizayn.\n" +
            "4. ⚫ **Minimal** - O'rtaga tekislangan, nafis va sokin vizual dizayn.",
      replyKeyboard: [
        ['🔵 Classic', '🟢 Modern'],
        ['🔴 Creative', '⚫ Minimal'],
        ['❌ Bekor qilish']
      ]
    };
  }

  if (session.state === 'CREATING_CV_DESIGN') {
    let selectedStyle: "classic" | "modern" | "creative" | "minimal" = "classic";
    if (text.includes("Classic") || text.toLowerCase().includes("classic")) selectedStyle = "classic";
    else if (text.includes("Modern") || text.toLowerCase().includes("modern")) selectedStyle = "modern";
    else if (text.includes("Creative") || text.toLowerCase().includes("creative")) selectedStyle = "creative";
    else if (text.includes("Minimal") || text.toLowerCase().includes("minimal")) selectedStyle = "minimal";

    session.cvDraft.designStyle = selectedStyle;
    session.state = 'CREATING_CV_COLOR';
    return {
      text: "Ajoyib tanlov! Shablon: " + selectedStyle.toUpperCase() + " 🎨\n\nEndi rezyumeingiz uchun asosiy rang mavzusini (Theme Color) tanlang:",
      replyKeyboard: [
        ['🖤 Slate (Tungi)', '💙 Blue (Moviy)'],
        ['💚 Emerald (Yashil)', '💖 Crimson (To\'q qizil)'],
        ['❌ Bekor qilish']
      ]
    };
  }

  if (session.state === 'CREATING_CV_COLOR') {
    let hexColor = "#1e293b";
    if (text.includes("Slate") || text.toLowerCase().includes("slate")) hexColor = "#1e293b";
    else if (text.includes("Blue") || text.toLowerCase().includes("blue")) hexColor = "#1d4ed8";
    else if (text.includes("Emerald") || text.toLowerCase().includes("emerald")) hexColor = "#047857";
    else if (text.includes("Crimson") || text.toLowerCase().includes("crimson")) hexColor = "#be185d";

    session.cvDraft.templateColor = hexColor;
    session.state = 'IDLE';

    // Call AI builder!
    const targetLang = session.lang;
    
    try {
      const generatedCV = await generateAICV(session.cvDraft, targetLang);
      
      // Inject selected design options into the finished model
      generatedCV.designStyle = session.cvDraft.designStyle || "classic";
      generatedCV.templateColor = hexColor;

      let formattedText = `🎉 **Muvaffaqiyatli rezyume yaratildi!**\n\n`;
      formattedText += `👤 **F.I.O:** ${generatedCV.fullName}\n`;
      formattedText += `📞 **Tel:** ${generatedCV.phone}\n`;
      formattedText += `📍 **Manzil:** ${generatedCV.location}\n`;
      formattedText += `🎨 **Shablon:** ${generatedCV.designStyle?.toUpperCase()} (${hexColor})\n\n`;
      formattedText += `💼 **Maqsadi:** ${generatedCV.summary}\n\n`;
      formattedText += `🎓 **Ta'lim:** ${generatedCV.education}\n\n`;
      formattedText += `🛠️ **Ko'nikmalar:** ${generatedCV.skills.join(', ')}\n\n`;
      
      if (generatedCV.experience && generatedCV.experience.length > 0) {
        formattedText += `🏢 **Ish tajribasi:**\n`;
        generatedCV.experience.forEach(exp => {
          formattedText += `- *${exp.position}* @ ${exp.company} (${exp.duration})\n  ${exp.description}\n`;
        });
        formattedText += `\n`;
      }
      formattedText += `🌐 **Tillar:** ${generatedCV.languages.map(l => `${l.language} - ${l.level}`).join(', ')}\n\n`;
      formattedText += `⬇️ Quyidagi maxsus tugma bilan yaratilgan **${generatedCV.designStyle.toUpperCase()}** dizaynidagi rezyumeni **PDF** formatida yuklab oling!`;

      const shortId = saveCvToStore(generatedCV);
      return {
        text: formattedText,
        replyKeyboard: getMainMenuButtons(session),
        cvData: generatedCV,
        documentUrl: `/api/cv/download?id=${shortId}&designStyle=${generatedCV.designStyle}&templateColor=${encodeURIComponent(hexColor)}`
      };
    } catch (e) {
      session.state = 'IDLE';
      return showMainMenu(session, "Kechirasiz, AI rezyume yaratishda xatolik yuz berdi. Iltimos qaytadan urinib ko'ring.");
    }
  }

  // 2. CV Improvement State (Before vs After)
  if (session.state === 'IMPROVING_CV') {
    session.state = 'IDLE';
    const initialMsg = "Yuborilgan rezyume tahlil qilinmoqda, takomillashtirish kiritilmoqda... ⏳";
    
    try {
      const results = await improveAICV(text);
      let improvementFormatted = `🔥 **REZYUME ANALIZI (Before vs After)**\n\n`;
      improvementFormatted += `❌ **XOM SIZNING NUMUNANGIZ (Eski):**\n_${results.before}_\n\n`;
      improvementFormatted += `✅ **AI PROFESSIONAL INTERPRETASIYASI (Yangi):**\n\n${results.after}\n\n`;
      improvementFormatted += `💡 **MUHIM O'ZGARTIRISHLAR:**\n`;
      results.suggestions.forEach((sug, i) => {
        improvementFormatted += `${i + 1}. ${sug}\n`;
      });
      improvementFormatted += `\n📱 *Ushbu format ijtimoiy tarmoqlar (TikTok/Instagram) va ATS tizimlari uchun eng ideal o'sish ko'rsatkichidir!*`;

      return {
        text: improvementFormatted,
        replyKeyboard: getMainMenuButtons(session)
      };
    } catch (e) {
      return showMainMenu(session, "Xatolik yuz berdi, CV tahlil qilina olmadi.");
    }
  }

  // 3. AI Cover Letter State
  if (session.state === 'COVER_LETTER_DESC') {
    session.state = 'IDLE';
    try {
      const dummyCV: CVData = {
        fullName: username,
        phone: "+998 90 999-12-34",
        email: "talaba@mail.uz",
        location: "Toshkent, O'zbekiston",
        education: "Oliy ta'lim talabasi",
        skills: ["Tashabbuskorlik", "Mijozlar bilan ishlash", "Muloqot"],
        experience: [],
        languages: [{ language: "O'zbek", level: "Mukammal" }]
      };
      
      const letter = await generateAICoverLetter(dummyCV, text, session.lang);
      
      let letterFormatted = `✉️ **Siz uchun AI Kuzatuv Xati (Cover Letter):**\n\n`;
      letterFormatted += letter;
      letterFormatted += `\n\n*Ushbu matnni nusxalab, ish beruvchiga ssenariy yoki xat ko'rinishida yuborishingiz mumkin!*`;

      return {
        text: letterFormatted,
        replyKeyboard: getMainMenuButtons(session)
      };
    } catch (e) {
      return showMainMenu(session, "AI Kuzatuv xatini yaratolmadi, tizim so'rovini tekshiring.");
    }
  }

  return showMainMenu(session, "Buyruq tushunarsiz bo'ldi. Asosiy menyudan foydalaning.");
}

// --- Dynamic Options & Help Keyboards ---

function getMainMenuButtons(session: UserSession): any[][] {
  const appUrl = process.env.APP_URL || "https://ais-pre-pwopdacpyx4cwt7pbyrh7y-786405147346.asia-southeast1.run.app";
  return [
    [{ text: "📲 AI Mini Appni ochish", web_app: { url: appUrl } }],
    ['📄 Yangi CV yaratish (AI)', '✨ CVni yaxshilash (AI)'],
    ["💼 Ishlar ro'yxati", '💡 Suhbatga tayyorgarlik'],
    ['✉️ Kuzatuv xati (AI Cover Letter)', '💳 Premium & To\'lov'],
    ['🇺🇿/🇬🇧 Tilni almashtirish']
  ];
}

function showMainMenu(session: UserSession, welcomeText: string): BotResponse {
  return {
    text: welcomeText,
    replyKeyboard: getMainMenuButtons(session)
  };
}

function showPremiumMenu(session: UserSession): BotResponse {
  let text = `💎 **RESUMEAI UZ PREMIUM PLANLAR** 💎\n\n`;
  text += `Bepul tarifda siz 1 marta bepul CV yarata olasiz. Premium tarif quyidagi ajoyib imkoniyatlarni ochadi:\n\n`;
  text += `⚡ Cheksiz AI Rezyume yaratish (O'zbek, Rus va Ingliz tilida)\n`;
  text += `⚡ Premium ATS and Vizual PDF andovalarini yuklash\n`;
  text += `⚡ Yo'naltirilgan vakansiyalarga avtomatik ulanish (Suhbat kafolati)\n`;
  text += `⚡ Har qanday soha uchun tayyorlangan HR ssenariylari va intervyular\n\n`;
  text += `💳 **TO'LOV VA TEZKOR FAOL SHeRIKLIK:**\n`;
  text += `To'lovni amalga oshirish va Premium maqomini tezkor faollashtirish uchun pastdagi tugmani bosing yoki to'g'ridan-to'g'ri administrator @positive_prog profiliga yozing!`;

  return {
    text,
    inlineKeyboard: [
      [
        { text: "🔵 Click orqali (29,000 UZS)", callbackData: "pay_click" },
        { text: "🟢 Payme orqali (29,000 UZS)", callbackData: "pay_payme" }
      ],
      [
        { text: "⭐️ Telegram Stars (50 Stars)", callbackData: "pay_stars" }
      ],
      [
        { text: "🔓 Premium maqomini tekshirish / Sinab ko'rish", callbackData: "check_premium" }
      ]
    ],
    replyKeyboard: getMainMenuButtons(session)
  };
}

function showJobsCategorySelection(): BotResponse {
  return {
    text: "Qaysi soha bo'yicha bo'sh ish o'rinlarini ko'rishni istaysiz? 🏢",
    replyKeyboard: [
      ['VAK_IT: 👨‍💻 Axborot Texnologiyalari (IT)'],
      ['VAK_sales: 🛍️ Sotuv va Muloqot'],
      ['VAK_teacher: 👩‍🏫 O\'qituvchilik'],
      ['VAK_driver: 🚗 Haydovchilik / Kuryerlik'],
      ['VAK_office: 📁 Ofis xizmatlari'],
      ['❌ Bekor qilish']
    ]
  };
}

async function handleVacanciesFilter(command: string): Promise<BotResponse> {
  const category = command.replace('VAK_', '').split(':')[0].trim();
  const jobs = getFilteredJobs(category, 'all');

  if (jobs.length === 0) {
    return {
      text: "Hozircha ushbu sohada faol bo'sh ish o'rinlari topilmadi. Tez orada yangi e'lonlar qo'shiladi!",
      replyKeyboard: [['❌ Bekor qilish']]
    };
  }

  let text = `🔍 **${category.toUpperCase()} bo'yicha eng so'nggi bo'sh ish o'rinlari:**\n\n`;
  jobs.forEach((job, i) => {
    text += `${i + 1}. **${job.title}**\n`;
    text += `🏢 Kompaniya: ${job.company}\n`;
    text += `💰 Maosh: ${job.salary}\n`;
    text += `📍 Joylashuv: ${job.location}\n`;
    text += `📋 Talablar: ${job.requirements.join(', ')}\n`;
    text += `✉️ Telegram aloqa: ${job.contact}\n\n`;
  });

  text += `👉 Ariza topshirish uchun to'g'ridan-to'g'ri ko'rsatilgan aloqa lichkasiga rezyumeingizni PDF formatida yuboring!`;

  return {
    text,
    replyKeyboard: [
      ['📄 Yangi CV yaratish (AI)'],
      ['❌ Bekor qilish']
    ]
  };
}

function showInterviewJobSelection(): BotResponse {
  return {
    text: "Qaysi ish turi bo'yicha tayyorgarlik ko'rmoqchisiz? 💡\nSuhbatda tushadigan eng qiyin savollar va ideal javoblarni o'zbek tilida tayyorlab beramiz.",
    replyKeyboard: [
      ['EXP_IT: IT Dasturchilik / Dizayn'],
      ['EXP_sales: Sotuv mutaxassisi / Konsultant'],
      ['EXP_office: Ofis administratori / Menejer'],
      ["EXP_ielts: Ingliz tili / IELTS so'zlashuv"],
      ['EXP_internship: Amaliyot / Fresh Graduates'],
      ['❌ Bekor qilish']
    ]
  };
}

async function handleInterviewPrepSelection(command: string): Promise<BotResponse> {
  const role = command.replace('EXP_', '').split(':')[0].trim();
  const prep = await generateAIInterviewPrep(role);

  let text = `💡 **${prep.jobType.toUpperCase()} SUHBATI UCHUN HR TAYYORGARLIK QO'LLANMASI** 💡\n\n`;
  
  prep.questions.forEach((q, idx) => {
    text += `📌 **Savol ${idx + 1}:** ${q.questionUz}\n`;
    text += `🇬🇧 *In English:* _${q.questionEn}_\n\n`;
    text += `✅ **Ideal Javob (O'zbekcha):**\n_${q.answerUz}_\n\n`;
    text += `🇬🇧 **English Sample Response:**\n_${q.answerEn}_\n\n`;
    text += `✍️ **Maslahat:** ${q.tipsUz}\n`;
    text += `-------------------------------------------\n\n`;
  });

  text += `🌟 *Tajriba: Savolga javob berayotganda duduqlanmasdan, samimiy muloqot qiling! Omad tilaymiz.*`;

  return {
    text,
    replyKeyboard: [
      ['📄 Yangi CV yaratish (AI)'],
      ['❌ Bekor qilish']
    ]
  };
}
