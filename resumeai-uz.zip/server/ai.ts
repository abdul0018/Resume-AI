import { GoogleGenAI, Type } from "@google/genai";
import { CVData, InterviewPrep } from "../src/types";

// Create and initialize the Google GenAI client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "MOCK_KEY_FOR_LOCAL_DEV",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const DEFAULT_MODEL = "gemini-3.5-flash";

// Helper check if Gemini is properly configured
const isGeminiKeySupplied = (): boolean => {
  return !!process.env.GEMINI_API_KEY && 
         process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY" && 
         process.env.GEMINI_API_KEY !== "MOCK_KEY_FOR_LOCAL_DEV" &&
         process.env.GEMINI_API_KEY.trim() !== "";
};

// Helper check if OpenAI is properly configured
const isOpenAIKeySupplied = (): boolean => {
  return !!process.env.OPENAI_API_KEY && 
         process.env.OPENAI_API_KEY !== "YOUR_OPENAI_API_KEY" && 
         process.env.OPENAI_API_KEY.trim() !== "";
};

// Helper check for overall API key absence
const isApiKeyMissing = (): boolean => {
  return !isGeminiKeySupplied() && !isOpenAIKeySupplied();
};

/**
 * Robust JSON cleanup and recovery utility
 * Parses JSON output from AI, coping with markdown wrappers, unescaped quotes, control characters, or trailing delimiters.
 */
export function cleanAndParseJSON<T>(rawText: string, fallback: T): T {
  if (!rawText) return fallback;
  let text = rawText.trim();
  
  // 1. Strip Markdown Code Fences
  if (text.startsWith("```")) {
    text = text.replace(/^```(?:json)?\n?/i, "");
    text = text.replace(/\n?```$/m, "");
  }
  text = text.trim();

  // 2. Bound matching delimiters
  const firstBrace = text.indexOf("{");
  const lastBrace = text.lastIndexOf("}");
  const firstBracket = text.indexOf("[");
  const lastBracket = text.lastIndexOf("]");

  let startIndex = -1;
  let endIndex = -1;

  if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
    startIndex = firstBrace;
    endIndex = lastBrace;
  } else if (firstBracket !== -1) {
    startIndex = firstBracket;
    endIndex = lastBracket;
  }

  if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
    text = text.substring(startIndex, endIndex + 1);
  }

  try {
    return JSON.parse(text) as T;
  } catch (error) {
    console.warn("Standard JSON.parse failed. Attempting robust inner quote / newline sanitization:", error);
    try {
      // Temporarily safe-keep already escaped sequences
      let sanitized = text.replace(/\\n/g, "[NL_PLACEHOLDER]");
      sanitized = sanitized.replace(/\\"/g, "[QUOTE_PLACEHOLDER]");
      
      // Clean raw newlines and raw double quotes inside JSON string property fields
      sanitized = sanitized.replace(/"([^"\\]*(?:\\.[^"\\]*)*)"/g, (match, contents) => {
        // Double-escape inner raw double quotes and replace real line-breaks with escaped '\n'
        const cleaned = contents
          .replace(/\n/g, "\\n")
          .replace(/\r/g, "")
          .replace(/[^\\]"/g, '\\"');
        return '"' + cleaned + '"';
      });

      // Restore placeholders
      sanitized = sanitized.replace(/\[NL_PLACEHOLDER\]/g, "\\n");
      sanitized = sanitized.replace(/\[QUOTE_PLACEHOLDER\]/g, '\\"');

      return JSON.parse(sanitized) as T;
    } catch (innerError: any) {
      console.error("Robust JSON Parsing totally failed. Falling back to default data structure:", innerError);
      return fallback;
    }
  }
}

/**
 * Universal AI Completion Wrapper
 * Calls Gemini first (if available); if Gemini is not configured or fails, falls back to OpenAI Chat Completions.
 */
async function generateWithAI(prompt: string, isJson: boolean = false, schema?: any): Promise<string> {
  // 1. Try Gemini
  if (isGeminiKeySupplied()) {
    try {
      const config: any = {};
      if (isJson) {
        config.responseMimeType = "application/json";
      }
      if (schema) {
        config.responseSchema = schema;
      }
      const response = await ai.models.generateContent({
        model: DEFAULT_MODEL,
        contents: prompt,
        config
      });
      if (response.text) {
        return response.text;
      }
    } catch (error) {
      console.warn("Gemini generation failed, checking OpenAI fallback...", error);
    }
  }

  // 2. Try OpenAI Fallback
  if (isOpenAIKeySupplied()) {
    try {
      const body: any = {
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7
      };
      if (isJson) {
        body.response_format = { type: "json_object" };
      }

      console.log("Routing resume request directly to OpenAI GPT model...");
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
        },
        body: JSON.stringify(body)
      });

      if (response.ok) {
        const data = await response.json();
        const content = data.choices?.[0]?.message?.content || "";
        if (content) {
          return content;
        }
      } else {
        const errorText = await response.text();
        console.error(`OpenAI integration returned error: ${response.status} - ${errorText}`);
      }
    } catch (openaiError) {
      console.error("OpenAI execution crashed:", openaiError);
    }
  }

  throw new Error("No active or valid Gemini/OpenAI credentials found in env configuration.");
}


/**
 * 1. AI CV Generator / Translater & Standardizer
 * Takes raw inputs and formats them into a polished, high-quality ATS-friendly format in Uzbek, Russian, or English.
 */
export async function generateAICV(input: Partial<CVData>, targetLang: 'uz' | 'ru' | 'en'): Promise<CVData> {
  if (isApiKeyMissing()) {
    // Return high quality customized mock data for offline development
    return getMockFormattedCV(input, targetLang);
  }

  const prompt = `
    You are an expert ATS (Applicant Tracking System) recruiter specializing in the Uzbekistan job market.
    Take the following raw candidate information and generate a professional, polished, and structured CV in the language: ${targetLang.toUpperCase()}.
    Make sure to translate properly, improve professional wording, correct grammatical mistakes, and split unstructured lists into clean arrays of skills.

    Raw candidate information:
    ${JSON.stringify(input, null, 2)}
  `;

  // Explicit type-safe responseSchema
  const cvSchema = {
    type: Type.OBJECT,
    properties: {
      fullName: { type: Type.STRING },
      phone: { type: Type.STRING },
      email: { type: Type.STRING },
      location: { type: Type.STRING },
      education: { type: Type.STRING },
      skills: {
        type: Type.ARRAY,
        items: { type: Type.STRING }
      },
      experience: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            company: { type: Type.STRING },
            position: { type: Type.STRING },
            duration: { type: Type.STRING },
            description: { type: Type.STRING }
          },
          required: ["company", "position", "duration", "description"]
        }
      },
      languages: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            language: { type: Type.STRING },
            level: { type: Type.STRING }
          },
          required: ["language", "level"]
        }
      },
      summary: { type: Type.STRING }
    },
    required: ["fullName", "phone", "email", "location", "education", "skills", "experience", "languages", "summary"]
  };

  const fallback = getMockFormattedCV(input, targetLang);

  try {
    const responseText = await generateWithAI(prompt, true, cvSchema);
    return cleanAndParseJSON<CVData>(responseText, fallback);
  } catch (error) {
    console.error("Error generating AI CV:", error);
    return fallback;
  }
}

/**
 * 2. Better CV Optimizer ("Before vs After" & TikTok Feature)
 * Takes unpolished text / raw resume content, identifies issues, improves grammar, and outlines bulleted changes.
 */
export async function improveAICV(rawCVText: string): Promise<{ before: string; after: string; suggestions: string[] }> {
  const fallback = {
    before: rawCVText || "Shuhrat Alimov | Tel: 998901234567 | Texnikum o'qiganman, soham sotuvchi. Do'konda ishlaganman 2 yil. Rus tilini o'rtacha bilaman.",
    after: "Shuhrat Alimov\nSotuv bo'yicha mutaxassis (Sales Specialist)\nTashkent, Uzbekistan | +998 (90) 123-45-67\n\nQISQACHA MA'LUMOT:\n2 yillik professional tajribaga ega, mijozlar bilan ishlash va sotuv hajmini oshirishga ixtisoslashgan sotuvchi. Mukammal muloqot va e'tirozlar bilan ishlash ko'nikmalariga ega.\n\nTashkilot: 'Oasis Retail' MCHJ (Tashkent)\nLavozim: Katta sotuvchi konsultant\nDavri: 2024 - Hozirgacha\n- Mijozlarga maslahat berish va brend mahsulotlarini faol sotish orqali oylik josa rejasini 120% ga bajarildi.\n- Tovar qoldiqlari nazorati va kassa hisob-kitoblarini yuritish tizimi joriy etildi.\n\nTILINGIZ:\n- O'zbek tili (Ona tili)\n- Rus tili (Muloqot darajasi - B1)\n\nKO'NIKMALAR:\n- B2C Savdo, Mijozlar bilan muloqot, CRM tizimlari, Moliyaviy hisobotlar, Kassa intizomi.",
    suggestions: [
      "Kasalmand va noaniq gaplar professional savdo atamalari bilan almashtirildi.",
      "Mijoz maslahatchisi o'rniga 'Katta sotuvchi konsultant' lavozimi va ko'nikmalari aniq shakllantirildi.",
      "Sotuv natijalari foiz ko'rsatkichlarida (120% isbotlangan muvaffaqiyat) formatlandi.",
      "ATS filtrlari o'qiy oladigan kalit so'zlar (CRM, B2C, Kassa intizomi) qo'shildi."
    ]
  };

  if (isApiKeyMissing()) {
    return fallback;
  }

  const prompt = `
    You are an elite career consultant in Central Asia.
    Analyze the following unpolished, poorly structured resume or description:
    ---
    ${rawCVText}
    ---

    Perform the following tasks:
    1. Correct spelling, grammar, and structural flow.
    2. Convert passive sentences to strong, result-driven active action-verbs tailored for the Uzbek market.
    3. Generate an "After" text version that looks incredibly elegant, formatted, and impactful.
    4. List 3 to 4 key improvement actions you completed to show of the "Before vs After" value proposition (ideal for marketing/TikTok comparison captions).
  `;

  const improveSchema = {
    type: Type.OBJECT,
    properties: {
      before: { type: Type.STRING },
      after: { type: Type.STRING },
      suggestions: {
        type: Type.ARRAY,
        items: { type: Type.STRING }
      }
    },
    required: ["before", "after", "suggestions"]
  };

  try {
    const responseText = await generateWithAI(prompt, true, improveSchema);
    return cleanAndParseJSON<{ before: string; after: string; suggestions: string[] }>(responseText, fallback);
  } catch (error) {
    console.error("Error improving AI CV:", error);
    return fallback;
  }
}

/**
 * 3. AI Cover Letter Generator
 * Generates tailored cover letter aligned with CV data & local job vacancy context.
 */
export async function generateAICoverLetter(cv: Partial<CVData>, jobDescription: string, targetLang: 'uz' | 'en'): Promise<string> {
  if (isApiKeyMissing()) {
    return getMockCoverLetter(cv, targetLang);
  }

  const prompt = `
    You are an expert recruitment writer.
    Write a tailored, high-converting professional Cover Letter (Kuzatuv xati) in ${targetLang === 'uz' ? 'Uzbek' : 'English'} for a candidate seeking a job in Uzbekistan.
    Maximize ATS compatibility, display professional enthusiasm, and tie the candidate's skills directly to the requirements.

    Candidate CV Highlight:
    ${JSON.stringify({ fullName: cv.fullName, education: cv.education, skills: cv.skills }, null, 2)}

    Target Job Description/Title:
    ${jobDescription}

    Format the response as a simple markdown string containing the complete cover letter (salutation, hook, body paragraphs linking skills, call to action, and professional closing).
  `;

  try {
    const responseText = await generateWithAI(prompt, false);
    return responseText || getMockCoverLetter(cv, targetLang);
  } catch (error) {
    console.error("Error generating Cover letter:", error);
    return getMockCoverLetter(cv, targetLang);
  }
}

/**
 * 4. Interview Prep Q&A Generator
 * Generates typical interview prep question guides for key job types in Uzbek and English.
 */
export async function generateAIInterviewPrep(jobType: string): Promise<InterviewPrep> {
  const fallback = getMockInterviewPrep(jobType);
  if (isApiKeyMissing()) {
    return fallback;
  }

  const prompt = `
    Generate a high-quality interview preparation Q&A guide for a Job Role: ${jobType}.
    Create exactly 4 critical, role-specific technical and behavioral questions widely asked by HR managers in Uzbek corporations or international startups. Must return in both Uzbek and English.
  `;

  const interviewSchema = {
    type: Type.OBJECT,
    properties: {
      jobType: { type: Type.STRING },
      questions: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            questionUz: { type: Type.STRING },
            questionEn: { type: Type.STRING },
            answerUz: { type: Type.STRING },
            answerEn: { type: Type.STRING },
            tipsUz: { type: Type.STRING }
          },
          required: ["questionUz", "questionEn", "answerUz", "answerEn", "tipsUz"]
        }
      }
    },
    required: ["jobType", "questions"]
  };

  try {
    const responseText = await generateWithAI(prompt, true, interviewSchema);
    return cleanAndParseJSON<InterviewPrep>(responseText, fallback);
  } catch (error) {
    console.error("Error generating Interview prep:", error);
    return fallback;
  }
}


// --- MOCK CONSTANTS / FALLBACKS FOR ROBUST OFFLINE / LITE WORKFLOWS ---

function getMockFormattedCV(input: Partial<CVData>, targetLang: 'uz' | 'ru' | 'en'): CVData {
  const isUz = targetLang === 'uz';
  const isRu = targetLang === 'ru';

  const defaultTitle = isUz ? "Professional Mutaxassis" : isRu ? "Профессиональный Специалист" : "Professional Specialist";

  return {
    fullName: input.fullName || "Jasur Alimov",
    phone: input.phone || "+998 90 987-65-43",
    email: input.email || "jasur.dev@mail.uz",
    location: input.location || (isUz ? "Toshkent, O'zbekiston" : isRu ? "Ташкент, Узбекистан" : "Tashkent, Uzbekistan"),
    education: input.education || (isUz ? "Toshkent Axborot Texnologiyalari Universiteti (TATU), Bakalavr" : "Tashkent University of Information Technologies (TUIT), BSc"),
    skills: input.skills && input.skills.length > 0 ? input.skills : ["React", "TypeScript", "Node.js", "SQL", "Git", (isUz ? "Faol muloqot" : "Teamwork")],
    experience: input.experience && input.experience.length > 0 ? input.experience : [
      {
        company: "UzTech Solutions",
        position: "Junior Web Developer",
        duration: "2023 - 2025",
        description: isUz
          ? "Kompaniyaning asosiy boshqaruv panellarini React-da optimallashtirish va tezlikni 35% ga oshirish. REST API integratsiyasi."
          : isRu
          ? "Оптимизация панели управления компании на React, повышение производительности на 35%. Интеграция REST API."
          : "Optimized corporate dashboards with React, leading to a 35% load time enhancement. Integrated robust RESTful APIs."
      }
    ],
    languages: input.languages && input.languages.length > 0 ? input.languages : [
      { language: isUz ? "O'zbek" : isRu ? "Узбекский" : "Uzbek", level: isUz ? "Ona tili" : "Native" },
      { language: isUz ? "Ingliz tili" : "English", level: "Intermediate (B2)" }
    ],
    summary: input.summary || (isUz 
      ? "Natijaga yo'naltirilgan va texnik bilimlarni amalda qo'llay oladigan mutaxassis. ATS talablariga javob beruvchi loyihalar muallifi."
      : "Results-driven specialist with verified experience building dynamic and lightweight web services tailored for client satisfaction.")
  };
}

function getMockCoverLetter(cv: Partial<CVData>, targetLang: 'uz' | 'en'): string {
  const name = cv.fullName || "Jasur Alimov";
  if (targetLang === 'uz') {
    return `### KUZATUV XATI (Cover Letter)

**Hurmatli Ish Beruvchi,**

Ushbu xat orqali sizning kompaniyangizda mavjud bo'lgan bo'sh ish o'rniga o'z nomzodimni taklif qilmoqchiman. Mening professional bilim va tajribam ushbu lavozim talablariga to'laqonli mos kelishiga ishonaman.

Mening asosiy kuchli tomonlarim:
- **Tez moslashuvchanlik**: Yangi professional yuklamalarni tez o'zlashtiraman.
- **Ko'nikmalar**: ${cv.skills?.join(', ') || 'Sotuv, IT ko\'nikmalari, Muammolarni hal qilish'}.
- **Ta'lim orqali ishonch**: ${cv.education || "Oliy ma'lumotli texnik mutaxassis"}.

O'zbekistondagi bozor dinamikasini va mijozlar psixologiyasini tushunishim kompaliyangiz rivojiga o'z hissasini qo'shishiga ishonchim komil. Savollar bo'lsa, istalgan vaqtda bog'lanishingizdan xursand bo'laman.

Samimiyat ila,
**${name}**
Telefon: ${cv.phone || "+998 90 987-65-43"}`;
  } else {
    return `### COVER LETTER

**Dear Hiring Committee,**

I am writing to express my enthusiastic interest in joining your team in the advertised position. Having analyzed the vacancy requirements and aligned them with my current professional trajectory, I believe I can make substantial contributions.

Key assets I bring to this position include:
- **Core Competencies**: ${cv.skills?.join(', ') || 'Sales, IT development, Critical troubleshooting'}.
- **Academic Foundation**: ${cv.education || "Bachelor level graduate"}.
- **Adaptability**: Passionate about utilizing AI tools to scale localized tasks securely.

Thank you for your time and consideration. I look forward to an opportunity to detail how my expertise translates to direct value for your active operations.

Sincerely,
**${name}**
Contact Number: ${cv.phone || "+998 90 987-65-43"}`;
  }
}

function getMockInterviewPrep(jobType: string): InterviewPrep {
  return {
    jobType: jobType || "Sales Specialist",
    questions: [
      {
        questionUz: "O'zingiz haqingizda qisqacha gapirib bering?",
        questionEn: "Could you briefly introduce yourself?",
        answerUz: "Mening ismim Jasur. 2 yildan buyon xalqaro va mahalliy do'konlarda mijozlar bilan ishlab kelaman. Mening vazifam xaridorlarga samimiy muloqot orqali mahsulot afzalliklarini tushuntirishdir.",
        answerEn: "My name is Jasur. For the past two years, I have worked in localized and national retail units managing customer relations. My primary objective has been to articulate product advantages with integrity.",
        tipsUz: "Javobingizni 1.5 - 2 daqiqadan oshirmang. Tajriba va asosiy natijalaringizga (masalan, sotuv rejasini qanchaga bajarganingiz) ko'proq e'tibor qarating."
      },
      {
        questionUz: "Nima uchun aynan bizning kompaniyani tanladingiz?",
        questionEn: "Why did you choose our company?",
        answerUz: "Sizning kompaniyangiz O'zbekiston bozorida sifat brendi sifatida tanilgan. Men bu yerda ilg'or o'sish metodlarini o'rganishim va jamoamiz sotuv ko'rsatkichini yangi darajaga olib chiqa olishimga ishonaman.",
        answerEn: "Your enterprise stands out as a benchmark of quality within the Uzbekistan market. I am drawn by your training standards and am convinced my focus will help push active sales quotas higher.",
        tipsUz: "Suhbatdan oldin kompaniya sayti yoki ijtimoiy tarmoqlarini kuzating. Kompaniyaning yutuqlari yoki qadriyatlarini tilga olib gapiring."
      },
      {
        questionUz: "Qiyin vaziyatlardan va muammoli xaridorlardan qanday chiqib ketasiz?",
        questionEn: "How do you handle difficult customers or stressful client situations?",
        answerUz: "Eng avvalo, his-tuyg'ularga berilmasdan xaridorni oxirigacha eshitaman. Muammoni tushungach, unga optimal (kompaniya qoidalariga mos) yechim taklif etaman. Stress - tajriba orttirish imkoniyati.",
        answerEn: "Firstly, I listen attentively without letting personal emotions interfere. Once the root issue is fully mapped, I pitch an optimal compromise authorized by official standard operating procedures.",
        tipsUz: "Aniq misol ('STAR' metodi: Situation, Task, Action, Result) keltirib gapirish suhbat olib boruvchida juda ijobiy ta'm qoldiradi."
      }
    ]
  };
}
