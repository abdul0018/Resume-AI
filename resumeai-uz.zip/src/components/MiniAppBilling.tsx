import React from "react";
import { Star, CheckCircle, CreditCard, Check } from "lucide-react";

interface MiniAppBillingProps {
  isPremium: boolean;
  isPayingSim: string | null;
  handleSimulatePayment: (method: string) => void;
}

export default function MiniAppBilling({
  isPremium,
  isPayingSim,
  handleSimulatePayment
}: MiniAppBillingProps) {
  return (
    <div className="flex flex-col h-full bg-slate-50 select-none p-4 text-left" id="billing_portal">
      <div className="flex-1 overflow-y-auto custom-scroll space-y-4 pb-4">
        
        {/* Banner with crown item */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-5 rounded-2xl text-white shadow-md relative overflow-hidden">
          {/* Subtle decoration */}
          <div className="absolute -right-3 -top-3 w-20 h-20 rounded-full bg-white/10" />
          
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 px-2.5 bg-white/20 hover:bg-white/35 rounded-lg text-[9px] uppercase tracking-wider font-extrabold flex items-center gap-1">
              <Star className="w-3 h-3 fill-amber-300 text-amber-300 shrink-0" /> VIP MEMBER
            </span>
          </div>
          
          <h3 className="text-sm font-black tracking-tight leading-snug">ResumeAI Premium (Lifetime)</h3>
          <p className="text-[10px] text-white/80 leading-relaxed mt-1">
            Bir marta harid qiling, va umrbod barcha cheksiz AI funksiyalaridan doimiy erkin foydalaning!
          </p>
        </div>

        {/* Pricing specs */}
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200/60 shadow-xs space-y-3.5">
          <div className="flex flex-col gap-1.5 border-b pb-3">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Premium To'liq Paketi</span>
            <h4 className="text-2xl font-black text-slate-900 font-sans flex items-baseline gap-1">
              29,000 UZS <span className="text-[10px] font-normal text-slate-400">/ abadiy (Lifetime)</span>
            </h4>
          </div>

          <ul className="space-y-2.5 mt-2">
            {[
              "Cheksiz Mars/ATS moslashtirilgan rezyumelar yaratish",
              "Barcha 4 turdagi visual PDF shablonlarni yuklash",
              "AI Cover Letter yordamchisi va tayyor intervyu Q&A",
              "Bo'sh ish o'rinlariga rezyumening moslik koeffitsiyenti",
              "Click, Payme va Telegram Stars to'lov tizimlarini qo'llash"
            ].map((feature, fid) => (
              <li key={fid} className="text-[10.5px] text-slate-600 flex items-start gap-2 font-medium leading-relaxed">
                <CheckCircle className="w-4 h-4 text-emerald-500 fill-emerald-500 text-white shrink-0 mt-0.5" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Action Payment simulator buttons */}
        <div className="space-y-2" id="sim_payments_box">
          {isPayingSim ? (
            <div className="text-center py-2.5 bg-blue-50 border border-blue-200 text-xs font-bold text-blue-700 rounded-xl animate-pulse">
              To'lov qayta ishlanmoqda... {isPayingSim.toUpperCase()}
            </div>
          ) : isPremium ? (
            <div className="text-center py-3 bg-emerald-500 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm">
              <Check className="w-4 h-4" /> Premium rejim muvaffaqiyatli faollashtirilgan!
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={() => handleSimulatePayment("click")}
                className="w-full text-center py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl active:scale-95 transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                💸 Click tizimi orqali to'lov (29,000 UZ)
              </button>
              <button
                type="button"
                onClick={() => handleSimulatePayment("payme")}
                className="w-full text-center py-2.5 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white font-bold text-xs rounded-xl active:scale-95 transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                💸 Payme tizimi orqali to'lov (29,000 UZS)
              </button>
              <a
                href="https://t.me/positive_prog"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full text-center py-2.5 bg-cyan-500 hover:bg-cyan-600 active:scale-95 transition-all text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                📱 Telegram orqali olish (@positive_prog)
              </a>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
