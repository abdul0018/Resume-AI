import React from "react";
import { 
  Building2, MapPin, Briefcase, Coins, 
  Search, Award, RefreshCw, Send, AlertCircle, FileCheck, CheckCircle 
} from "lucide-react";
import { JobVacancy } from "../types";

interface MiniAppJobsProps {
  jobs: JobVacancy[];
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  activeLocation: string;
  setActiveLocation: (loc: string) => void;
  isLoadingJobs: boolean;
  selectedJobForMatch: JobVacancy | null;
  setSelectedJobForMatch: (job: JobVacancy | null) => void;
  matchScore: number | null;
  matchReport: string;
  isCalculatingMatch: boolean;
  handleTestAICVMatch: (job: JobVacancy) => Promise<void>;
  cvFullName: string;
}

export default function MiniAppJobs({
  jobs,
  activeCategory,
  setActiveCategory,
  activeLocation,
  setActiveLocation,
  isLoadingJobs,
  selectedJobForMatch,
  setSelectedJobForMatch,
  matchScore,
  matchReport,
  isCalculatingMatch,
  handleTestAICVMatch,
  cvFullName
}: MiniAppJobsProps) {

  const categories = [
    { id: "all", label: "Barcha sohalar" },
    { id: "it", label: "IT & Dasturlash" },
    { id: "sales", label: "Savdo & Marketing" },
    { id: "delivery", label: "Logistika & Haydovchilik" },
    { id: "other", label: "Boshqa xizmatlar" }
  ];

  const locations = [
    { id: "all", label: "Barcha viloyatlar" },
    { id: "tashkent", label: "Toshkent sh." },
    { id: "samarkand", label: "Samarqand" },
    { id: "andijan", label: "Andijon" },
    { id: "fergana", label: "Farg'ona" }
  ];

  return (
    <div className="flex flex-col h-full bg-slate-50 select-none" id="jobs_portal_container">
      {/* Search Header filters */}
      <div className="p-4 bg-white border-b border-slate-200/60 shrink-0 space-y-3">
        <div className="flex gap-2">
          {/* Category Dropdown */}
          <div className="flex-1">
            <label className="block text-[9px] uppercase font-bold text-slate-400 mb-1">Kasbiy Yo'nalish</label>
            <select
              value={activeCategory}
              onChange={(e) => setActiveCategory(e.target.value)}
              className="w-full text-xs font-semibold px-2 py-1.5 border border-slate-200 rounded-xl outline-none bg-white font-sans text-slate-700 hover:border-slate-300"
            >
              {categories.map(cat => (
                <option key={cat.id} value={cat.id}>{cat.label}</option>
              ))}
            </select>
          </div>

          {/* Location Dropdown */}
          <div className="flex-1">
            <label className="block text-[9px] uppercase font-bold text-slate-400 mb-1">Hudud bo'yicha</label>
            <select
              value={activeLocation}
              onChange={(e) => setActiveLocation(e.target.value)}
              className="w-full text-xs font-semibold px-2 py-1.5 border border-slate-200 rounded-xl outline-none bg-white font-sans text-slate-700 hover:border-slate-300"
            >
              {locations.map(loc => (
                <option key={loc.id} value={loc.id}>{loc.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Jobs feed or AI match details */}
      <div className="flex-1 overflow-y-auto p-4 custom-scroll space-y-3" id="jobs_scroller">
        
        {/* IF CHOSEN AN ACTIVE AI MATCH ANALYSIS */}
        {selectedJobForMatch && (
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3.5" id="ai_match_panel">
            <div className="flex items-center justify-between border-b pb-2">
              <span className="text-xs font-bold text-blue-900">AI Rezyume moslik hisoboti</span>
              <button 
                onClick={() => setSelectedJobForMatch(null)}
                className="text-[10px] text-slate-400 hover:text-red-500 font-bold hover:underline"
              >
                Orqaga (Vakansiyalar ro'yxatiga)
              </button>
            </div>

            <div className="flex items-center gap-3">
              <span className="p-2.5 bg-blue-50 text-blue-800 rounded-xl shrink-0">
                <Building2 className="w-5 h-5" />
              </span>
              <div>
                <h4 className="text-xs font-bold text-slate-800 leading-snug">{selectedJobForMatch.title}</h4>
                <p className="text-[10px] text-slate-400 font-medium">{selectedJobForMatch.company} | {selectedJobForMatch.salary}</p>
              </div>
            </div>

            {isCalculatingMatch ? (
              <div className="flex flex-col items-center justify-center py-6 gap-3">
                <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
                <span className="text-[10px] font-bold text-slate-500 font-mono tracking-widest animate-pulse">
                  AI rezyumeingizni tahlil qilmoqda...
                </span>
              </div>
            ) : matchScore !== null ? (
              <div className="space-y-3.5">
                {/* Score badge details */}
                <div className="flex items-center gap-4 bg-slate-50 p-3.5 rounded-2xl border">
                  {/* Dynamic Score Dial */}
                  <div className="relative w-16 h-16 shrink-0 flex items-center justify-center rounded-full bg-white border shadow-sm">
                    <span className="text-sm font-black font-mono text-blue-800">{matchScore}%</span>
                    <svg className="absolute inset-0 w-full h-full rotate-270 scale-[0.9]">
                      <circle
                        cx="32"
                        cy="32"
                        r="28"
                        stroke="#f1f5f9"
                        strokeWidth="4"
                        fill="transparent"
                      />
                      <circle
                        cx="32"
                        cy="32"
                        r="28"
                        stroke={matchScore >= 75 ? "#10b981" : "#3b82f6"}
                        strokeWidth="4"
                        fill="transparent"
                        strokeDasharray={2 * Math.PI * 28}
                        strokeDashoffset={2 * Math.PI * 28 * (1 - matchScore / 100)}
                      />
                    </svg>
                  </div>
                  <div>
                    <h5 className="text-xs font-extrabold text-slate-800">
                      {matchScore >= 75 ? "Moslik darajasi Yuqori! 🌟" : "O'rtacha moslik darajasi 💬"}
                    </h5>
                    <p className="text-[10px] text-slate-400 mt-1 lines-clamp-2 leading-snug">
                      Kandidat: {cvFullName || "Jasur Alimov"}. Rezultati ATS bo'yicha tahlil qilindi.
                    </p>
                  </div>
                </div>

                {/* AI report txt */}
                <div className="p-3 bg-blue-50/30 text-[10.5px] text-slate-700 rounded-xl leading-relaxed whitespace-pre-wrap border border-blue-100/30">
                  {matchReport}
                </div>

                <a 
                  href={`https://t.me/positive_prog`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full text-center py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-md cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" /> HR bilan bog'lanish va Rezyume topshirish
                </a>
              </div>
            ) : null}
          </div>
        )}

        {/* LOADING STATE */}
        {isLoadingJobs ? (
          <div className="flex flex-col items-center justify-center py-12 gap-2 text-slate-400">
            <RefreshCw className="w-6 h-6 animate-spin text-slate-300" />
            <span className="text-[10px] font-bold font-mono tracking-wider animate-pulse">Ma'lumotlar yuklanmoqda...</span>
          </div>
        ) : jobs.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs">
            Ushbu qidiruv bo'yicha do'kon yoki bo'sh ish o'rni topilmadi.
          </div>
        ) : !selectedJobForMatch && (
          <div className="space-y-3">
            {jobs.map((job) => (
              <div 
                key={job.id} 
                className="bg-white p-4.5 rounded-2xl border border-slate-200/60 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all text-left space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <span className="px-2 py-0.5 bg-blue-50 hover:bg-blue-100 text-[9px] font-bold text-blue-700 rounded-md uppercase font-mono tracking-wider">
                      {job.category.toUpperCase()}
                    </span>
                    <h4 className="text-xs font-black text-slate-800 leading-tight block select-text">
                      {job.title}
                    </h4>
                    <p className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                      <Building2 className="w-3 h-3 text-slate-300 shrink-0" /> {job.company}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-[11px] font-black text-slate-800 font-mono tracking-tight block">
                      {job.salary}
                    </span>
                    <span className="text-[9px] text-slate-400 font-medium block mt-0.5">oylik daromad</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-slate-100 pt-2.5 text-[10px] text-slate-500 font-medium">
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3 shrink-0" /> {job.location}</span>
                  <span>•</span>
                  <span>E'lon qilingan: {job.postedAt}</span>
                </div>

                <div className="bg-slate-50/50 p-2.5 rounded-xl text-[10px] text-slate-600/90 leading-relaxed whitespace-normal border">
                  <span className="font-bold text-slate-700 block mb-1 uppercase text-[9px]">Talablar:</span>
                  <ul className="list-disc pl-3.5 space-y-1">
                    {job.requirements.map((req, rid) => (
                      <li key={rid} className="leading-tight select-text">{req}</li>
                    ))}
                  </ul>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleTestAICVMatch(job)}
                    className="flex-1 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] rounded-lg transition-all active:scale-95 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <FileCheck className="w-3.5 h-3.5" /> AI Moslikni Tahlillash
                  </button>
                  <a 
                    href={`https://t.me/positive_prog`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[10.2px] rounded-lg active:scale-95 transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Send className="w-3 h-3 text-slate-500" /> Bog'lanish
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
