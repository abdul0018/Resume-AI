import React, { useRef, useEffect } from "react";
import { 
  Bot, Briefcase, User, FileText, Send, Paperclip, 
  Smile, Mic, Check, CheckCheck, RefreshCw, Star, Download, Sparkles 
} from "lucide-react";
import { CVData } from "../types";

export interface ChatMessage {
  id: string;
  sender: "user" | "bot";
  text: string;
  replyMarkup?: string[][];
  inlineButtons?: { text: string; url?: string; callbackData?: string }[];
  documentUrl?: string;
  cvCreated?: any;
}

interface TelegramChatProps {
  chatHistory: ChatMessage[];
  userInput: string;
  setUserInput: (input: string) => void;
  isSimulatingTyping: boolean;
  handleSendSimulatedMessage: (messageText: string) => Promise<void>;
  tgActiveChatId: string;
  setTgActiveChatId: (chatId: string) => void;
  isPremium: boolean;
  cvForm: CVData;
  themeColor: string;
  setActiveTab: (tab: "bot" | "builder" | "jobs" | "assistants" | "billing") => void;
  setMobileNavMode: (mode: "chat" | "webapp") => void;
}

export default function TelegramChat({
  chatHistory,
  userInput,
  setUserInput,
  isSimulatingTyping,
  handleSendSimulatedMessage,
  tgActiveChatId,
  setTgActiveChatId,
  isPremium,
  cvForm,
  themeColor,
  setActiveTab,
  setMobileNavMode
}: TelegramChatProps) {

  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isSimulatingTyping, tgActiveChatId]);

  const chatsList = [
    { id: "bot", title: "ResumeAI UZ Bot", subtitle: "online assistant", isVerified: true, icon: Bot, isBot: true },
    { id: "jobs_chan", title: "@bobo_vakansiya", subtitle: "8.4K subscribers", isVerified: false, icon: Briefcase, isBot: false },
    { id: "supp_chat", title: "Sardor (VIP Support)", subtitle: "online xizmati", isVerified: true, icon: User, isBot: false },
    { id: "my_cvs", title: "Mening Rezyumelarim", subtitle: "saqlangan hujjatlar", isVerified: false, icon: FileText, isBot: false }
  ];

  const handleInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userInput.trim()) {
      handleSendSimulatedMessage(userInput);
    }
  };

  return (
    <div className="flex h-full bg-[#17212b] overflow-hidden rounded-2xl shadow-xl border border-slate-800" id="telegram_desktop_wrapper">
      {/* 1. LEFT SIDE CHATS LIST (35% width on lg) */}
      <div className="w-1/3 border-r border-[#101921] h-full flex flex-col bg-[#17212b]" id="telegram_sidebar">
        
        {/* Telegram header search bar */}
        <div className="p-3 bg-[#17212b] border-b border-[#101921] shrink-0">
          <input
            type="search"
            readOnly
            placeholder="Qidirish... (Search)"
            className="w-full bg-[#24303f] border border-transparent focus:border-[#2b5278] outline-none rounded-lg px-2.5 py-1.5 text-xs text-slate-300 font-sans"
          />
        </div>

        {/* Chats active list */}
        <div className="flex-1 overflow-y-auto custom-scroll" id="sidebar_chats_feed">
          {chatsList.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setTgActiveChatId(chat.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 transition-all text-left border-b border-[#101921]/40 ${
                tgActiveChatId === chat.id 
                  ? "bg-[#2b5278] text-white" 
                  : "bg-transparent text-slate-300 hover:bg-[#202b36]"
              }`}
            >
              {/* Profile icon */}
              <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 shadow-sm ${
                tgActiveChatId === chat.id ? "bg-white/20" : "bg-slate-700/60"
              }`}>
                <chat.icon className="w-4 h-4 text-white" />
              </div>

              {/* Chat labels */}
              <div className="flex-1 overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-sans tracking-wide truncate flex items-center gap-1">
                    {chat.title}
                    {chat.isVerified && (
                      <span className="w-3.5 h-3.5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[8px] font-black shrink-0">
                        ✓
                      </span>
                    )}
                  </span>
                  <span className="text-[9px] text-slate-400 font-mono">11:58</span>
                </div>
                <p className="text-[10px] text-slate-400 truncate mt-0.5 font-medium leading-relaxed">
                  {chat.id === "bot" && isSimulatingTyping ? "typing..." : chat.subtitle}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 2. RIGHT ACTIVE CHAT area (65% width) */}
      <div className="flex-1 h-full flex flex-col bg-[#0e1621] relative" id="telegram_chat_viewport">
        
        {/* Active chat top navigation */}
        {(() => {
          const currentChat = chatsList.find(c => c.id === tgActiveChatId) || chatsList[0];
          return (
            <div className="px-4 py-3 bg-[#17212b] border-b border-[#101921] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-slate-700 flex items-center justify-center text-white shrink-0">
                  <currentChat.icon className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <h4 className="text-xs font-bold text-slate-100 flex items-center gap-1">
                    {currentChat.title}
                    {currentChat.isVerified && (
                      <span className="w-3.5 h-3.5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[8px] font-black shrink-0">
                        ✓
                      </span>
                    )}
                  </h4>
                  <span className="text-[10px] text-slate-400 font-semibold leading-none">
                    {currentChat.id === "bot" && isSimulatingTyping ? "yozilmoqda (typing...)" : currentChat.subtitle}
                  </span>
                </div>
              </div>
            </div>
          );
        })()}

        {/* CHAT MESSAGES PANEL */}
        <div 
          className="flex-1 overflow-y-auto p-4 space-y-3.5 custom-scroll bg-[#0e1621]" 
          style={{ backgroundImage: "linear-gradient(rgba(14,22,33,0.95), rgba(14,22,33,0.95)), url('https://telegram.org/img/t_wallpaper.png')" }}
          id="chat_bubbles_box"
        >
          {tgActiveChatId === "bot" && (
            <>
              {chatHistory.map((message) => {
                const isBot = message.sender === "bot";
                return (
                  <div 
                    key={message.id} 
                    className={`flex ${isBot ? "justify-start" : "justify-end"} items-end gap-2.5 max-w-full`}
                  >
                    {isBot && (
                      <div className="w-7 h-7 rounded-full bg-blue-600/80 hover:bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                        R
                      </div>
                    )}
                    <div 
                      className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 shadow-md text-left flex flex-col gap-1.5 ${
                        isBot 
                          ? "bg-[#182533] text-slate-100 rounded-bl-none" 
                          : "bg-[#2b5278] text-white rounded-br-none"
                      }`}
                    >
                      {/* message textual context */}
                      <p className="text-xs whitespace-pre-wrap leading-relaxed select-text font-sans break-words">
                        {message.text}
                      </p>

                      {/* inline attachments */}
                      {message.documentUrl && (
                        <div className="bg-[#101921] p-2.5 rounded-xl flex items-center justify-between gap-3 select-none mt-1 border border-slate-700/40">
                          <div className="flex items-center gap-2">
                            <span className="p-2 bg-blue-600 rounded-lg text-white">
                              <FileText className="w-4 h-4" />
                            </span>
                            <div className="text-left font-sans">
                              <span className="text-[10px] uppercase font-bold text-slate-300 block">Rezyume PDF shakli</span>
                              <span className="text-[9px] text-slate-400 block">Tayyor yuklab olishga</span>
                            </div>
                          </div>
                          <a 
                            href={message.documentUrl}
                            download
                            className="p-1 px-2.5 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-[9.5px] font-bold flex items-center gap-1 shrink-0 transition-all active:scale-95"
                          >
                            <Download className="w-3 h-3" /> Yuklash
                          </a>
                        </div>
                      )}

                      {/* Reply timestamps */}
                      <div className="text-[8.5px] text-slate-400 self-end font-mono flex items-center gap-1 leading-none mt-1 select-none">
                        <span>11:58</span>
                        {!isBot && <CheckCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Simulated typing animation bubble */}
              {isSimulatingTyping && (
                <div className="flex justify-start items-end gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-blue-600/80 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                    R
                  </div>
                  <div className="bg-[#182533] text-slate-400 rounded-2xl rounded-bl-none px-4 py-3 shadow-md text-left font-mono text-[10px] flex items-center gap-1 font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "0ms" }}></span>
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "150ms" }}></span>
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "300ms" }}></span>
                  </div>
                </div>
              )}
            </>
          )}

          {/* JOBS CHANNEL SIMULATED POSTS */}
          {tgActiveChatId === "jobs_chan" && (
            <div className="space-y-4">
              <div className="text-center py-2 text-slate-400/85 text-[10px] font-bold bg-[#17212b]/60 max-w-sm rounded-lg mx-auto font-mono uppercase tracking-wider select-none">
                E'lonlar kanali • 8,432 a'zo
              </div>

              {[
                { title: "SMM loyiha boshqaruvchisi", salary: "8,000,000", reqs: "SMM savodxonligi, Canva, Rus tili", company: "Zamon Agency" },
                { title: "Sotuv menejeri (Retail sales)", salary: "11,000,000", reqs: "Muloqot ko'nikmasi, B2C, faollik", company: "Sadaf Savdo" }
              ].map((jobItem, jId) => (
                <div key={jId} className="max-w-[85%] mx-auto bg-[#182533] text-slate-200 p-4 rounded-2xl border border-slate-700/30 text-left space-y-3 shadow-md font-sans">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="px-2 py-0.5 bg-blue-900 text-blue-200 text-[8px] font-mono rounded font-bold uppercase">KANAL POSTI</span>
                      <h4 className="text-xs font-black block text-white mt-1.5 leading-tight">{jobItem.title}</h4>
                      <p className="text-[9.5px] text-slate-400 font-bold mt-1">Shtab: {jobItem.company}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-[11px] font-extrabold text-[#5288c1] font-mono block">{jobItem.salary} UZS</span>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-300 leading-relaxed bg-[#101921] p-2 rounded-xl">
                    <strong className="text-[9px] uppercase tracking-wider text-slate-500 block">Talablar:</strong>
                    - {jobItem.reqs}
                  </p>

                  <button
                    onClick={() => {
                      window.open("https://t.me/bobo_vakansiya", "_blank");
                    }}
                    className="w-full text-center py-1.5 bg-[#2b5278] hover:bg-[#346290] text-white text-[10px] font-bold rounded-lg transition-all"
                  >
                    Batafsil ma'lumot (Kanal) 🚀
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* SUPPORT MANAGER LIVE CHAT SIM */}
          {tgActiveChatId === "supp_chat" && (
            <div className="space-y-3">
              <div className="flex justify-start items-end gap-2.5 max-w-[85%]">
                <div className="w-7 h-7 rounded-full bg-slate-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                  SM
                </div>
                <div className="bg-[#182533] text-slate-100 rounded-2xl rounded-bl-none px-4 py-3 shadow-md text-left font-sans text-xs space-y-2 leading-relaxed">
                  <p>
                    Assalomu alaykum! Ismim Sardor. ResumeAI UZ premium xizmati va do'konimizga xush kelibsiz. 😊
                  </p>
                  <p>
                    Chet tillari kiritish, A4 formati bilan PDF yuklash, yoki <strong>Click / Payme</strong> to'lovlarini faollashtirishda muammo bo'lsa, menga yozing. Tezda yordam beramiz!
                  </p>
                  <div className="text-[8.5px] text-slate-400 font-mono text-right leading-none select-none">
                    Menejer • 11:58
                  </div>
                </div>
              </div>

              {/* dynamic prompt feedback helpers */}
              <div className="flex flex-wrap justify-end gap-1.5 max-w-sm ml-auto select-none mt-4">
                {[
                  "To'lov muvaffaqiyatli bo'lmadimi?",
                  "Mening profilim premiummi?",
                  "Qanday qilib rasm yuklayman?"
                ].map((txt) => (
                  <button
                    key={txt}
                    onClick={() => handleSendSimulatedMessage(txt)}
                    className="px-2.5 py-1.5 bg-slate-800 text-slate-300 text-[10px] font-bold rounded-lg border border-slate-700/40 hover:bg-[#2b5278] hover:text-white transition-all"
                  >
                    {txt}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* MY SAVED DOCUMENTS REPOSITORY ARCHIVE */}
          {tgActiveChatId === "my_cvs" && (
            <div className="space-y-4">
              <div className="text-center py-2 text-slate-400/80 text-[10px] font-bold bg-[#17212b]/65 max-w-xs rounded-lg mx-auto font-mono uppercase tracking-wider select-none">
                Hujjatlar ombori • 2 fayl
              </div>

              <div className="bg-[#182533] p-4 rounded-2xl border border-slate-700/30 text-left space-y-3 shadow-md max-w-[85%] mx-auto font-sans">
                <div className="flex items-center gap-3">
                  <span className="p-2.5 bg-blue-900 rounded-xl text-blue-200">
                    <FileText className="w-5 h-5 animate-pulse" />
                  </span>
                  <div>
                    <h4 className="text-xs font-black text-white uppercase">{cvForm.fullName || "JASUR ALIMOV"} REZYUMESI</h4>
                    <p className="text-[10px] text-slate-400 font-bold">{cvForm.location || "Toshkent"} | {cvForm.phone || "+998"}</p>
                  </div>
                </div>

                <div className="flex gap-2 select-none pt-1">
                  <button
                    onClick={() => {
                      setActiveTab("builder");
                      setMobileNavMode("webapp");
                    }}
                    className="flex-1 py-1.5 bg-[#2b5278] hover:bg-[#396b9c] text-white text-[10px] font-bold rounded-lg transition-all"
                  >
                    Tahrirlash 📝
                  </button>
                  <button
                    onClick={() => handleSendSimulatedMessage("📄 Men yaratgan CVni yuklash")}
                    className="px-4 py-1.5 bg-slate-800 text-slate-300 text-[10px] font-bold rounded-lg transition-all"
                  >
                    Darsga tushirish
                  </button>
                </div>
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* PERSISTENT REPLY KEYBOARDS FOR BOT CHAT */}
        {tgActiveChatId === "bot" && chatHistory.length > 0 && chatHistory[chatHistory.length - 1].replyMarkup && (
          <div className="bg-[#17212b] p-2.5 border-t border-[#101921] shrink-0 space-y-1.5 select-none" id="reply_keyboards">
            {chatHistory[chatHistory.length - 1].replyMarkup?.map((row, rowIdx) => (
              <div key={rowIdx} className="flex gap-2">
                {row.map((btnText) => (
                  <button
                    key={btnText}
                    onClick={() => handleSendSimulatedMessage(btnText)}
                    className="flex-1 text-center py-2.5 bg-[#24303f] hover:bg-[#2b5278] hover:text-white text-[11px] text-slate-200 font-bold rounded-xl transition-all border border-[#101921]/20 cursor-pointer active:scale-97 truncate"
                  >
                    {btnText}
                  </button>
                ))}
              </div>
            ))}
          </div>
        )}

        {/* Telegram Chat message input box footer */}
        <form 
          onSubmit={handleInputSubmit}
          className="px-3.5 py-3.5 bg-[#17212b] border-t border-[#101921] shrink-0 flex items-center justify-between gap-3 select-none"
          id="telegram_chat_input_form"
        >
          {/* Paperclip */}
          <button 
            type="button"
            className="text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* input */}
          <input
            type="text"
            placeholder="Xabar yozing (Write message)..."
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-slate-200 text-xs placeholder:text-slate-500 py-1"
          />

          {/* Emotion */}
          <div className="flex items-center gap-3 text-slate-400">
            <button type="button" className="hover:text-slate-200 cursor-pointer"><Smile className="w-5 h-5" /></button>
            <button type="button" className="hover:text-slate-200 cursor-pointer"><Mic className="w-5 h-5" /></button>
            <button 
              type="submit" 
              className={`p-1.5 rounded-full ${
                userInput.trim() ? "text-blue-500 hover:bg-slate-800" : "text-slate-500"
              } cursor-pointer`}
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
