import React from "react";
import { 
  Sparkles, GraduationCap, Award, HelpCircle, RefreshCw, 
  FileText, ArrowRight, CheckCircle 
} from "lucide-react";
import { InterviewPrep } from "../types";

interface MiniAppAssistantsProps {
  activeSubAgent: "interview" | "cover";
  setActiveSubAgent: (agent: "interview" | "cover") => void;
  selectedJobRole: string;
  setSelectedJobRole: (role: string) => void;
  interviewPrepData: InterviewPrep | null;
  isGeneratingPrep: boolean;
  handleGenerateInterviewQA: () => Promise<void>;
  jobCoverLetterDesc: string;
  setJobCoverLetterDesc: (desc: string) => void;
  generatedLetter: string;
  isGeneratingLetter: boolean;
  handleGenerateLetter: () => Promise<void>;
}

export default function MiniAppAssistants({
  activeSubAgent,
  setActiveSubAgent,
  selectedJobRole,
  setSelectedJobRole,
  interviewPrepData,
  isGeneratingPrep,
  handleGenerateInterviewQA,
  jobCoverLetterDesc,
  setJobCoverLetterDesc,
  generatedLetter,
  isGeneratingLetter,
  handleGenerateLetter
}: MiniAppAssistantsProps) {

  const jobRoles = [
    "Sales Specialist (Sotuvchi mudir)",
    "SMM & Digital Marketer",
    "English Language Teacher",
    "Logistic Logistics Manager",
    "React Frontend Developer",
    "Mobile App Developer (Flutter/Kotlin)"
  ];

  return (
    <div className="flex flex-col h-full bg-slate-50 select-none" id="assistants_scroller_container">
      {/* Tab Switcher upper */}
      <div className="px-4 py-3 bg-white border-b border-slate-200/60 shrink-0 flex gap-2">
        <button
          onClick={() => setActiveSubAgent("interview")}
          className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeSubAgent === "interview" 
              ? "bg-blue-600 text-white shadow-sm"
              : "bg-slate-50 text-slate-500 hover:bg-slate-100"
          }`}
        >
          🎓 Suhbat tayyorgarligi
        </button>
        <button
          onClick={() => setActiveSubAgent("cover")}
          className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeSubAgent === "cover" 
              ? "bg-blue-600 text-white shadow-sm"
              : "bg-slate-50 text-slate-500 hover:bg-slate-100"
          }`}
        >
          ✉️ Kuzatuv Xati (Cover Letter)
        </button>
      </div>

      {/* Main Container Scrollable */}
      <div className="flex-1 overflow-y-auto p-4 custom-scroll space-y-3" id="assistants_scroller">
        
        {/* INTERVIEW COOPERATOR PRACTICE */}
        {activeSubAgent === "interview" ? (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200/60 shadow-xs space-y-3 flex flex-col text-left">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Kutilayotgan Kasb/Lavozim</label>
                <select
                  value={selectedJobRole}
                  onChange={(e) => setSelectedJobRole(e.target.value)}
                  className="w-full text-xs font-bold px-3 py-2 border border-slate-200 rounded-xl outline-none bg-white font-sans text-slate-700 hover:border-slate-300 cursor-pointer"
                >
                  {jobRoles.map((role) => (
                    <option key={role} value={role}>{role}</option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleGenerateInterviewQA}
                disabled={isGeneratingPrep}
                className="w-full text-center py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 active:scale-95 disabled:opacity-50 transition-all shadow-sm cursor-pointer"
              >
                {isGeneratingPrep ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Generatsiya qilinmoqda...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 fill-white" />
                    HR Savol-Javoblarni Yaratish (AI)
                  </>
                )}
              </button>
            </div>

            {/* If has generated data */}
            {isGeneratingPrep ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <RefreshCw className="w-7 h-7 animate-spin text-blue-600" />
                <span className="text-[10px] tracking-wider font-bold text-slate-400 font-mono animate-pulse uppercase">
                  AI suhbat savollarini to'plamoqda...
                </span>
              </div>
            ) : interviewPrepData ? (
              <div className="space-y-4 text-left">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1 border-l-2 border-blue-600">
                  Lavozim: {interviewPrepData.jobType}
                </div>

                {interviewPrepData.questions.map((q, idx) => (
                  <div key={idx} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
                    {/* Header question */}
                    <div className="flex gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-blue-50 text-blue-800 text-[10px] font-bold flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <div className="flex-1 space-y-1">
                        <h4 className="text-xs font-black text-slate-800 leading-tight select-text">
                          {q.questionUz}
                        </h4>
                        <p className="text-[9.5px] font-mono text-slate-400 italic">
                          ENG: {q.questionEn}
                        </p>
                      </div>
                    </div>

                    {/* Answer tips block */}
                    <div className="bg-slate-50/50 p-3 rounded-xl border space-y-2">
                      <div className="text-[9.5px] font-bold text-blue-900 border-b pb-1 uppercase font-display flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-blue-700" /> Tavsiyaviy eng munosib javob matni:
                      </div>
                      <p className="text-[10.5px] text-slate-700 leading-relaxed select-text font-sans">
                        {q.answerUz}
                      </p>
                      <div className="text-[9px] font-mono text-slate-400 leading-relaxed italic border-t pt-1.5 select-text">
                        ENG: {q.answerEn}
                      </div>

                      {/* Coach Tips */}
                      {q.tipsUz && (
                        <div className="text-[10px] italic text-emerald-800 bg-emerald-50/40 p-2 rounded-lg leading-relaxed mt-2 border border-emerald-100/40 select-text">
                          💡 HR COACH AYTADI: {q.tipsUz}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 rounded-2xl border-2 border-dashed border-slate-200 text-slate-400 text-xs">
                Ushbu bo'limda siz istalgan sohaga doir professional HR suhbatlarining eng qiyin savollari va tayyor inglizcha javoblari ssenariysini mustaqil tahlil qilishingiz mumkin.
              </div>
            )}
          </div>
        ) : (
          /* COVER LETTER CREATION SECTION */
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200/60 shadow-xs space-y-3.5 flex flex-col text-left">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Murojaat qilinayotgan vakansiya details</label>
                <input 
                  type="text"
                  value={jobCoverLetterDesc}
                  onChange={(e) => setJobCoverLetterDesc(e.target.value)}
                  placeholder="Smm menejeri, Toshkent Korzinka do'koni"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl outline-none bg-white text-slate-700 hover:border-slate-300 font-sans"
                />
              </div>

              <button
                onClick={handleGenerateLetter}
                disabled={isGeneratingLetter}
                className="w-full text-center py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm active:scale-95 disabled:opacity-50 transition-all cursor-pointer"
              >
                {isGeneratingLetter ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Generatsiya qilinmoqda...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 fill-white" />
                    Kuzatuv Xatini Yaratish (AI Letter)
                  </>
                )}
              </button>
            </div>

            {/* Generated results letter */}
            {isGeneratingLetter ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <RefreshCw className="w-7 h-7 animate-spin text-blue-600" />
                <span className="text-[10px] tracking-wider font-bold text-slate-400 font-mono animate-pulse uppercase">
                  AI Kuzatuv matnini shakllantirmoqda...
                </span>
              </div>
            ) : generatedLetter ? (
              <div className="space-y-3 text-left">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1 border-l-2 border-indigo-600">
                  Kuzatuv xati yaratildi
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3 font-sans leading-relaxed text-[11px] text-slate-700 whitespace-pre-wrap select-text relative">
                  <div className="absolute top-3 right-3 text-[8px] font-bold font-mono text-slate-300 select-none">
                    AI generated letter
                  </div>
                  {generatedLetter}
                </div>
              </div>
            ) : (
              <div className="text-center py-12 rounded-2xl border-2 border-dashed border-slate-200 text-slate-400 text-xs">
                Yuqoridagi maydonga o'zingiz loyihalashtirmoqchi bo'lgan kompaniya va bo'sh ish o'rni yoki o'zingiz haqingizda xohishlarni yozing, va tizim bir zumda professional Cover Letter yaratib beradi.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
