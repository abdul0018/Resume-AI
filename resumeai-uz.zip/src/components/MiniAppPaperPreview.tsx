import React from "react";
import { Download, RefreshCw, User, Mail, Phone, MapPin, Briefcase, BookOpen, Award, Languages } from "lucide-react";
import { CVData } from "../types";
import { generatePdfCV } from "../utils/pdfGenerator";

interface MiniAppPaperPreviewProps {
  cvForm: CVData;
  themeColor: string;
  isGeneratingCV: boolean;
  onClosePreview?: () => void;
}

export default function MiniAppPaperPreview({
  cvForm,
  themeColor,
  isGeneratingCV,
  onClosePreview
}: MiniAppPaperPreviewProps) {
  const style = cvForm.designStyle || "classic";

  const handleDownloadPdf = () => {
    generatePdfCV(cvForm, themeColor);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900" id="cv_paper_preview_container">
      {/* Visual Top Actions */}
      <div className="px-4 py-3 bg-slate-800 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-xs font-bold text-slate-300 font-mono">LIVE PREVIEW</span>
        </div>
        <div className="flex gap-2">
          {onClosePreview && (
            <button
              onClick={onClosePreview}
              className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-bold rounded-lg transition-all"
            >
              Tahrirlashga qaytish ✍️
            </button>
          )}
          <button
            onClick={handleDownloadPdf}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold rounded-lg flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
            id="download_pdf_doc_btn"
          >
            <Download className="w-3.5 h-3.5" /> A4 PDF Yuklab Olish (Haqiqiy)
          </button>
        </div>
      </div>

      {/* Simulator Paper Canvas Scrollholder */}
      <div className="flex-1 overflow-y-auto p-4 custom-scroll bg-slate-950 flex items-center justify-center min-h-[400px]">
        <div 
          className="w-full max-w-[600px] bg-white text-slate-800 rounded-md shadow-2xl p-6 sm:p-8 font-sans text-[11px] md:text-xs leading-relaxed transition-all duration-300 relative border border-slate-200 select-none"
          id="sim_card_pdf_layout"
        >
          {/* WATERMARK ACCENT */}
          <div className="absolute right-3 bottom-3 text-[8px] font-bold font-mono text-slate-200 uppercase tracking-widest pointer-events-none">
            ResumeAI UZ ATS Tested
          </div>

          {/* DYNAMIC HEADER BASED ON STYLE */}
          {(() => {
            if (style === "creative") {
              return (
                <div 
                  className="p-5 rounded-lg flex items-center justify-between gap-4 mb-5" 
                  style={{ backgroundColor: `${themeColor}12`, borderTop: `5px solid ${themeColor}` }}
                >
                  <div className="flex-1 text-left">
                    <h4 className="text-xl font-bold tracking-tight mb-1.5 uppercase font-display" style={{ color: themeColor }}>
                      {cvForm.fullName || "JASUR ALIMOV"}
                    </h4>
                    <div className="text-[10px] text-slate-500 font-medium flex flex-wrap gap-x-3 gap-y-1">
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3 shrink-0" /> {cvForm.location || "Toshkent, O'zbekiston"}</span>
                      <span className="flex items-center gap-1"><Phone className="w-3 h-3 shrink-0" /> {cvForm.phone || "+998 (90) 123-45-67"}</span>
                      {cvForm.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3 shrink-0" /> {cvForm.email}</span>}
                    </div>
                  </div>
                  {cvForm.picture ? (
                    <img src={cvForm.picture} className="w-14 h-14 rounded-full object-cover border-2 shrink-0 shadow-sm" style={{ borderColor: themeColor }} alt="Profile" />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-slate-100 flex items-center justify-center text-slate-300 border">
                      <User className="w-6 h-6" />
                    </div>
                  )}
                </div>
              );
            }
            if (style === "modern") {
              return (
                <div className="border-b pb-4 mb-4 flex items-center justify-between gap-4 border-l-4 pl-4" style={{ borderColor: themeColor }}>
                  <div className="flex-1 text-left">
                    <h4 className="text-xl font-extrabold tracking-tight mb-2 uppercase font-display" style={{ color: themeColor }}>
                      {cvForm.fullName || "JASUR ALIMOV"}
                    </h4>
                    <div className="text-[10px] text-slate-500 font-semibold flex flex-wrap gap-x-3 gap-y-1">
                      <span className="flex items-center gap-1">📍 {cvForm.location || "Toshkent"}</span>
                      <span className="flex items-center gap-1">📞 {cvForm.phone || "+998 (90) 123-45-67"}</span>
                      {cvForm.email && <span className="flex items-center gap-1">✉️ {cvForm.email}</span>}
                    </div>
                  </div>
                  {cvForm.picture ? (
                    <img src={cvForm.picture} className="w-14 h-14 rounded-md object-cover border shrink-0 shadow-sm" style={{ borderColor: themeColor }} alt="Profile" />
                  ) : (
                    <div className="w-14 h-14 rounded bg-slate-50 border flex items-center justify-center text-slate-300">
                      <User className="w-6 h-6" />
                    </div>
                  )}
                </div>
              );
            }
            if (style === "minimal") {
              return (
                <div className="pb-5 mb-5 flex flex-col items-center justify-center text-center gap-3 border-b border-slate-100">
                  {cvForm.picture ? (
                    <img src={cvForm.picture} className="w-16 h-16 rounded-full object-cover border border-slate-200 shadow-sm" alt="Profile" />
                  ) : null}
                  <div>
                    <h4 className="text-xl font-light tracking-widest text-slate-800 uppercase font-display">
                      {cvForm.fullName || "JASUR ALIMOV"}
                    </h4>
                    <div className="text-[9px] text-slate-400 uppercase tracking-widest mt-1.5 flex flex-wrap justify-center gap-x-3 gap-y-1">
                      <span>📍 {cvForm.location || "Toshkent, O'zbekiston"}</span>
                      <span>•</span>
                      <span>📞 {cvForm.phone || "+998 (90) 123-45-67"}</span>
                      {cvForm.email && (
                        <>
                          <span>•</span>
                          <span>✉️ {cvForm.email}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            }
            // Classic ATS default
            return (
              <div className="border-b pb-4 mb-4 flex items-center justify-between gap-4 border-slate-200">
                <div className="flex-1 text-left">
                  <h4 className="text-xl font-bold tracking-tight mb-1 font-display" style={{ color: themeColor }}>
                    {cvForm.fullName || "JASUR ALIMOV"}
                  </h4>
                  <div className="text-[10.5px] text-slate-500 font-medium">
                    📍 {cvForm.location || "Toshkent, O'zbekiston"} &nbsp;|&nbsp; 📞 {cvForm.phone || "+998 (90) 123-45-67"}
                    {cvForm.email && `  |  ✉️ ${cvForm.email}`}
                  </div>
                </div>
                {cvForm.picture ? (
                  <img src={cvForm.picture} className="w-14 h-14 rounded-md object-cover border border-slate-200 shrink-0 shadow-sm" alt="Profile" />
                ) : null}
              </div>
            );
          })()}

          {/* SECTION BULLET BUILDER ACCENT RENDERING */}
          {(() => {
            const renderSectionTitle = (title: string) => {
              if (style === "creative") {
                return (
                  <div className="text-[9px] font-bold uppercase tracking-wider text-white px-2.5 py-0.5 rounded shadow-sm inline-block mb-2 font-mono" style={{ backgroundColor: themeColor }}>
                    {title}
                  </div>
                );
              }
              if (style === "modern") {
                return (
                  <div className="border-l-3 pl-2.5 text-[9.5px] font-extrabold uppercase tracking-wider mb-2 font-display" style={{ borderColor: themeColor, color: themeColor }}>
                    {title}
                  </div>
                );
              }
              if (style === "minimal") {
                return (
                  <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-800 border-b border-slate-100 pb-1 mb-2">
                    {title}
                  </div>
                );
              }
              // Classic
              return (
                <div className="text-[10px] font-bold uppercase tracking-wider border-b pb-0.5 mb-2 font-display flex items-center justify-between" style={{ borderColor: themeColor, color: themeColor }}>
                  <span>{title}</span>
                </div>
              );
            };

            return (
              <div className="space-y-4 text-left">
                {/* 1. Summary */}
                {cvForm.summary && (
                  <div>
                    {renderSectionTitle("PROFESSIONAL SUMMARY")}
                    <p className="text-slate-600 leading-relaxed font-sans mt-1 pl-0.5">
                      {cvForm.summary}
                    </p>
                  </div>
                )}

                {/* 2. Skills */}
                {cvForm.skills && cvForm.skills.length > 0 && (
                  <div>
                    {renderSectionTitle("TECHNICAL AND SOFT SKILLS")}
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {cvForm.skills.map((skill, i) => (
                        <span 
                          key={i} 
                          className="px-2 py-0.5 bg-slate-50 border border-slate-100 text-[10px] text-slate-700 rounded font-medium"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. Experience */}
                {cvForm.experience && cvForm.experience.length > 0 && (
                  <div>
                    {renderSectionTitle("WORK EXPERIENCE")}
                    <div className="space-y-3 font-sans mt-2">
                      {cvForm.experience.map((exp, i) => (
                        <div key={i} className="border-l border-slate-100 pl-3 relative">
                          <div className="absolute top-1.5 -left-[4.5px] w-2.5 h-2.5 rounded-full bg-slate-100 border border-slate-300"></div>
                          <div className="flex items-center justify-between text-[11px] font-semibold">
                            <span className="text-slate-900 font-bold">{exp.company || "Yashirin Kompaniya"}</span>
                            <span className="text-slate-400 text-[9.5px] font-normal">{exp.duration || "Hozirgacha"}</span>
                          </div>
                          <div className="text-[10px] text-blue-800 font-bold italic mt-0.5" style={{ color: themeColor }}>
                            {exp.position || "Kandidat Hamshira/Assistent"}
                          </div>
                          <p className="text-slate-500 mt-1 pl-1 whitespace-pre-wrap leading-relaxed text-[10.5px]">
                            {exp.description || "Lavozim vazifalari shakllantirilmagan."}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 4. Education */}
                {cvForm.education && (
                  <div>
                    {renderSectionTitle("EDUCATION AND QUALIFICATIONS")}
                    <p className="text-slate-600 leading-relaxed font-sans mt-1 pl-1">
                      {cvForm.education}
                    </p>
                  </div>
                )}

                {/* 5. Languages */}
                {cvForm.languages && cvForm.languages.length > 0 && (
                  <div>
                    {renderSectionTitle("LANGUAGES")}
                    <div className="flex flex-wrap gap-x-5 gap-y-1 mt-1 pl-1">
                      {cvForm.languages.map((l, i) => (
                        <div key={i} className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: themeColor }}></span>
                          <span className="text-slate-800 font-bold text-[10.5px]">{l.language}</span>
                          <span className="text-slate-400 text-[9.5px]">({l.level})</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
}
