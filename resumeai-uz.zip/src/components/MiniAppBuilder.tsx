import React from "react";
import { 
  User, Phone, MapPin, Mail, Briefcase, Plus, Trash2, 
  Sparkles, GraduationCap, Languages, Palette, ChevronLeft, ChevronRight, Eye, RefreshCw 
} from "lucide-react";
import { CVData } from "../types";

interface MiniAppBuilderProps {
  cvForm: CVData;
  setCvForm: React.Dispatch<React.SetStateAction<CVData>>;
  themeColor: string;
  setThemeColor: (color: string) => void;
  rawSkillInput: string;
  setRawSkillInput: (input: string) => void;
  isGeneratingCV: boolean;
  handleBuildAICVWeb: () => Promise<void>;
  addExperienceField: () => void;
  removeExperienceField: (index: number) => void;
  handleExperienceChange: (index: number, field: string, value: string) => void;
  addLanguageField: () => void;
  removeLanguageField: (index: number) => void;
  handleLanguageChange: (index: number, field: string, value: string) => void;
  cvBuilderStep: number;
  setCvBuilderStep: React.Dispatch<React.SetStateAction<number>>;
  setShowMiniAppCvPreview: (show: boolean) => void;
}

export default function MiniAppBuilder({
  cvForm,
  setCvForm,
  themeColor,
  setThemeColor,
  rawSkillInput,
  setRawSkillInput,
  isGeneratingCV,
  handleBuildAICVWeb,
  addExperienceField,
  removeExperienceField,
  handleExperienceChange,
  addLanguageField,
  removeLanguageField,
  handleLanguageChange,
  cvBuilderStep,
  setCvBuilderStep,
  setShowMiniAppCvPreview
}: MiniAppBuilderProps) {

  const nextStep = () => {
    if (cvBuilderStep < 4) setCvBuilderStep(prev => prev + 1);
  };

  const prevStep = () => {
    if (cvBuilderStep > 1) setCvBuilderStep(prev => prev - 1);
  };

  return (
    <div className="flex flex-col h-full bg-white select-none" id="mini_app_builder_wizard">
      {/* Wizard Progress bar */}
      <div className="p-4 bg-slate-50 border-b border-slate-200/60 shrink-0">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
            Qadam {cvBuilderStep} / 4
          </span>
          <span className="text-xs font-bold text-slate-800">
            {cvBuilderStep === 1 && "👤 Aloqa va Ma'lumot"}
            {cvBuilderStep === 2 && "💼 Ish Faoliyati"}
            {cvBuilderStep === 3 && "🎓 Ta'lim va Ko'nikma"}
            {cvBuilderStep === 4 && "🎨 Dizayn va Ranglar"}
          </span>
        </div>
        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden flex gap-0.5">
          {[1, 2, 3, 4].map((step) => (
            <div 
              key={step} 
              className={`flex-1 h-full transition-all duration-300 ${
                cvBuilderStep >= step ? "bg-blue-600" : "bg-slate-200"
              }`} 
            />
          ))}
        </div>
      </div>

      {/* Step Contents - Scrollable Box */}
      <div className="flex-1 overflow-y-auto p-4 custom-scroll" id="step_scroller">
        
        {/* STEP 1: Personal Details */}
        {cvBuilderStep === 1 && (
          <div className="space-y-4">
            {/* profile photo upload */}
            <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200/50">
              <div className="relative w-16 h-16 rounded-full border border-slate-300 flex items-center justify-center bg-white overflow-hidden shrink-0 group shadow-sm">
                {cvForm.picture ? (
                  <img src={cvForm.picture} className="w-full h-full object-cover" alt="Avatar" />
                ) : (
                  <User className="w-6 h-6 text-slate-300" />
                )}
                <label className="absolute inset-0 bg-black/45 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <span className="text-[10px] font-bold text-white text-center px-1">Yuklash</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = () => {
                          setCvForm({ ...cvForm, picture: reader.result as string });
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </label>
              </div>
              <div className="flex-1 flex flex-col">
                <span className="text-xs font-bold text-slate-700">Profil Rasmingiz</span>
                <p className="text-[10px] text-slate-400">Rezyumeda chiqishi uchun rasm yuklang.</p>
                {cvForm.picture && (
                  <button 
                    type="button" 
                    onClick={() => setCvForm({ ...cvForm, picture: "" })}
                    className="text-[10px] text-red-500 font-bold hover:underline self-start mt-1"
                  >
                    Profil rasmini o'chirish
                  </button>
                )}
              </div>
            </div>

            {/* General form fields */}
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">To'liq ism-sharifingiz *</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-400"><User className="w-4 h-4" /></span>
                  <input 
                    type="text"
                    required
                    placeholder="Jasur Alimov"
                    value={cvForm.fullName}
                    onChange={(e) => setCvForm({ ...cvForm, fullName: e.target.value })}
                    className="w-full pl-9 px-3.5 py-2 text-xs border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Telefon raqamingiz *</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-400"><Phone className="w-4 h-4" /></span>
                  <input 
                    type="text"
                    required
                    placeholder="+998 (90) 123-45-67"
                    value={cvForm.phone}
                    onChange={(e) => setCvForm({ ...cvForm, phone: e.target.value })}
                    className="w-full pl-9 px-3.5 py-2 text-xs border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl outline-none transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Email manzilingiz</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400"><Mail className="w-3.5 h-3.5" /></span>
                    <input 
                      type="email"
                      placeholder="jasur@gmail.com"
                      value={cvForm.email || ""}
                      onChange={(e) => setCvForm({ ...cvForm, email: e.target.value })}
                      className="w-full pl-8.5 px-3 py-2 text-xs border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Yashash manzilingiz</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400"><MapPin className="w-3.5 h-3.5" /></span>
                    <input 
                      type="text"
                      placeholder="Toshkent, Sergeli"
                      value={cvForm.location}
                      onChange={(e) => setCvForm({ ...cvForm, location: e.target.value })}
                      className="w-full pl-8.5 px-3 py-2 text-xs border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl outline-none transition-all"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Karyera Maqsadi (Professional Summary)</label>
                <textarea 
                  rows={3}
                  placeholder="Loyihalarni muvaffaqiyatli boshqarish, savdo hajmini oshirish hamda jamoani boshqarish burchidagi tajribali mutaxassis..."
                  value={cvForm.summary || ""}
                  onChange={(e) => setCvForm({ ...cvForm, summary: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs text-slate-800 border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl outline-none transition-all resize-none leading-relaxed"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Work Experience */}
        {cvBuilderStep === 2 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5"><Briefcase className="w-4 h-4 text-blue-600" /> Ish Tajribalaringiz ro'yxati</h4>
              <button
                type="button" 
                onClick={addExperienceField}
                className="text-xs text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Qo'shish
              </button>
            </div>

            {cvForm.experience.length === 0 ? (
              <div className="text-center py-8 rounded-xl border-2 border-dashed border-slate-100 text-slate-400 text-xs">
                Ish joylari qo'shilmagan. Talabalar uchun bo'sh qoldirish mumkin.
              </div>
            ) : (
              <div className="space-y-4">
                {cvForm.experience.map((exp, index) => (
                  <div key={index} className="p-3.5 bg-slate-50 border border-slate-200/60 rounded-xl space-y-2.5 relative">
                    <button
                      type="button"
                      onClick={() => removeExperienceField(index)}
                      className="absolute top-3.5 right-3.5 text-slate-400 hover:text-red-500 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="text-xs font-bold text-blue-800 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 text-[10px]">{index + 1}</span>
                      Ish joyi tafsiloti
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">Kompaniya nomi</label>
                        <input 
                          type="text"
                          placeholder="Korzinka LLC"
                          value={exp.company}
                          onChange={(e) => handleExperienceChange(index, "company", e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg outline-none bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">Lavozim</label>
                        <input 
                          type="text"
                          placeholder="Sotuv menejeri"
                          value={exp.position}
                          onChange={(e) => handleExperienceChange(index, "position", e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg outline-none bg-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">Ishlash davri (Duration)</label>
                        <input 
                          type="text"
                          placeholder="2023 - Hozirgacha"
                          value={exp.duration}
                          onChange={(e) => handleExperienceChange(index, "duration", e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg outline-none bg-white"
                        />
                      </div>
                      <div className="invisible"></div>
                    </div>

                    <div>
                      <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">Vazifa va yutuqlar (ATS Optimized bullets uchun)</label>
                      <textarea 
                        rows={2}
                        placeholder="Mijozlar bilan ishlash, oyiga 12% savdo hajmini oshirish, yangi sotuv skriptlarini yaratish..."
                        value={exp.description}
                        onChange={(e) => handleExperienceChange(index, "description", e.target.value)}
                        className="w-full px-2.5 py-1.5 text-[11px] border border-slate-200 rounded-lg outline-none bg-white resize-none"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* STEP 3: Education & Skills */}
        {cvBuilderStep === 3 && (
          <div className="space-y-4">
            <div>
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-2"><GraduationCap className="w-4 h-4 text-blue-600" /> Ta'lim darajasi va Joyi</h4>
              <textarea 
                rows={2}
                placeholder="Toshkent Davlat Iqtisodiyot Universiteti, Iqtisodchi mutaxassisligi (Bakalavr, 2019-2023)"
                value={cvForm.education}
                onChange={(e) => setCvForm({ ...cvForm, education: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-200 focus:border-blue-500 rounded-xl outline-none resize-none leading-relaxed"
              />
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-1"><Sparkles className="w-4 h-4 text-blue-600" /> Ko'nikmalar (Skills - vergul bilan ajralgan)</h4>
              <p className="text-[10px] text-slate-400 mb-2">Eng muhim ko'nikmalarni vergul (,) orqali yozing.</p>
              <textarea 
                rows={2.5}
                placeholder="Mijozlar bilan muzokara, CRM tizimlar, Rus tili, Excel, B2B Savdo, Slayd taqdimotlar"
                value={rawSkillInput}
                onChange={(e) => setRawSkillInput(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 focus:border-blue-500 rounded-xl outline-none resize-none font-mono"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5"><Languages className="w-4 h-4 text-blue-600" /> Chet tillari darajalari</h4>
                <button
                  type="button" 
                  onClick={addLanguageField}
                  className="text-xs text-blue-600 font-bold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Til qo'shish
                </button>
              </div>

              {cvForm.languages.length === 0 ? (
                <div className="text-center py-4 rounded-xl bgcolor bg-slate-50 text-slate-400 text-[10px]">
                  Chet tillari kiritilmadi. (Rezyumeingizda chiqmaydi).
                </div>
              ) : (
                <div className="space-y-2">
                  {cvForm.languages.map((item, langIdx) => (
                    <div key={langIdx} className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200/50">
                      <input 
                        type="text"
                        value={item.language}
                        placeholder="Ingliz tili"
                        onChange={(e) => handleLanguageChange(langIdx, "language", e.target.value)}
                        className="flex-1 px-2 py-1 text-xs border border-slate-200 rounded-lg outline-none bg-white"
                      />
                      <select
                        value={item.level}
                        onChange={(e) => handleLanguageChange(langIdx, "level", e.target.value)}
                        className="px-2 py-1 text-xs border border-slate-200 rounded-lg outline-none bg-white font-medium"
                      >
                        <option value="Mukammal">Mukammal (C1/C2)</option>
                        <option value="O'rtacha">O'rta (B1/B2)</option>
                        <option value="Boshlang'ich">Boshlang'ich (A1/A2)</option>
                      </select>
                      <button
                        type="button"
                        onClick={() => removeLanguageField(langIdx)}
                        className="text-slate-400 hover:text-red-500 p-1 shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 4: Design Style & Color Selection */}
        {cvBuilderStep === 4 && (
          <div className="space-y-4">
            <div>
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-2.5"><Palette className="w-4 h-4 text-blue-600" /> Rezyume Shablonini tanlang (Styles like rezyume.uz)</h4>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  { id: "classic", title: "Classic ATS", desc: "Konservativ qoralamalar" },
                  { id: "modern", title: "Modern Split", desc: "Zamonoviylashtirilgan split" },
                  { id: "creative", title: "Premium Hero", desc: "Logotip va yuqori banner" },
                  { id: "minimal", title: "Minimal Silent", desc: "Generuz oq va toza shablon" }
                ].map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => {
                      setCvForm(prev => ({ ...prev, designStyle: option.id as any }));
                    }}
                    className={`flex flex-col text-left p-3 rounded-xl border-2 transition-all ${
                      (cvForm.designStyle || "classic") === option.id
                        ? "border-blue-600 bg-blue-50/20 text-blue-900 shadow-sm font-semibold scale-[1.01]"
                        : "border-slate-200 bg-white hover:border-slate-300 text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <span className="text-xs font-bold">{option.title}</span>
                    <span className="text-[9px] text-slate-400 mt-1">{option.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-2"><Palette className="w-4 h-4 text-blue-600" /> Rang Mavzusini tanlang (Palette selection)</h4>
              <div className="flex flex-wrap gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-200/50">
                {[
                  { color: "#1e293b", label: " Slate" },
                  { color: "#1d4ed8", label: " Blue" },
                  { color: "#047857", label: " Emerald" },
                  { color: "#be185d", label: " Pink" },
                  { color: "#b91c1c", label: " Crimson" },
                  { color: "#7c2d12", label: " Terracotta" }
                ].map((item) => (
                  <button
                    key={item.color}
                    type="button"
                    onClick={() => setThemeColor(item.color)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold border active:scale-95 transition-all text-slate-700 bg-white"
                    style={{ 
                      borderColor: themeColor === item.color ? themeColor : "#cbd5e1" ,
                      borderWidth: themeColor === item.color ? "2px" : "1px"
                    }}
                  >
                    <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: item.color }} />
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="border border-blue-100 bg-blue-50/40 p-4 rounded-xl flex items-start gap-3">
              <span className="p-1.5 bg-blue-100 rounded-lg text-blue-700"><Sparkles className="w-4 h-4 fill-blue-700" /></span>
              <div className="flex-1">
                <h5 className="text-xs font-bold text-blue-950">AI ATS Optimallashtirish</h5>
                <p className="text-[10px] text-blue-800/80 leading-relaxed mt-1">
                  Matndagi kamchiliklarni to'g'rilab, professional ATS-friendly jumlalarga o'tkazishni Gemini AI bevosita amalga oshiradi!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Wizard Bottom navigation */}
      <div className="px-4 py-3 bg-slate-50 border-t border-slate-200/80 shrink-0 flex items-center justify-between gap-3">
        <div className="flex gap-2">
          {cvBuilderStep > 1 ? (
            <button
              onClick={prevStep}
              className="px-3.5 py-2 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all border border-slate-200 flex items-center gap-1 bg-white cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" /> Avvalgisi
            </button>
          ) : (
            <button
              onClick={() => setShowMiniAppCvPreview(true)}
              className="px-3.5 py-2 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-all border border-slate-300 flex items-center gap-1.5 bg-white cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" /> Ko'rish 👁️
            </button>
          )}

          {cvBuilderStep < 4 ? (
            <button
              onClick={nextStep}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1 cursor-pointer"
            >
              Keyingisi <ChevronRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={() => setShowMiniAppCvPreview(true)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              CV Ko'rish <Eye className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <button
          onClick={handleBuildAICVWeb}
          disabled={isGeneratingCV}
          className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shadow-md active:scale-95 disabled:opacity-50 cursor-pointer"
        >
          {isGeneratingCV ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              Yuklanmoqda...
            </>
          ) : (
            <>
              <Sparkles className="w-3.5 h-3.5 fill-white" />
              AI formatlash ⚡
            </>
          )}
        </button>
      </div>
    </div>
  );
}
