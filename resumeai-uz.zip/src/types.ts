export interface CVData {
  fullName: string;
  phone: string;
  email?: string;
  location: string;
  education: string;
  skills: string[];
  experience: {
    company: string;
    position: string;
    duration: string;
    description: string;
  }[];
  languages: {
    language: string;
    level: string; // e.g. Boshlang'ich (A1/A2), O'rta (B1/B2), Mukammal (C1/C2)
  }[];
  summary?: string;
  templateColor?: string;
  picture?: string; // Base64 encoded or image URL
  designStyle?: "classic" | "modern" | "creative" | "minimal";
}

export interface JobVacancy {
  id: string;
  title: string;
  company: string;
  salary: string;
  location: string;
  category: string;
  description: string;
  requirements: string[];
  contact: string;
  postedAt: string;
}

export interface InterviewPrep {
  jobType: string;
  questions: {
    questionUz: string;
    questionEn: string;
    answerUz: string;
    answerEn: string;
    tipsUz: string;
  }[];
}

export interface PaymentSimulation {
  userId: string;
  amount: number;
  provider: 'Click' | 'Payme' | 'Stars';
  status: 'PENDING' | 'SUCCESS' | 'FAILED';
  premiumDurationDays: number;
}
