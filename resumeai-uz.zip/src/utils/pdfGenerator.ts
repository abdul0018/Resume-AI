import { jsPDF } from "jspdf";
import { CVData } from "../types";

export function generatePdfCV(cv: CVData, colorTheme: string = "#1e293b") {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4"
  });

  const primaryColor = colorTheme; // Custom or selected theme color
  const secondaryColor = "#475569"; // Slate gray
  const style = cv.designStyle || "classic"; // "classic" | "modern" | "creative" | "minimal"

  // Margins
  const lMargin = 15;
  let yVal = 20;
  const pgWidth = doc.internal.pageSize.getWidth();
  
  // Set maximum header text width to avoid overlap with profile picture if present
  const baseMaxWidth = pgWidth - 2 * lMargin; // 180mm
  const headerTextMaxWidth = cv.picture ? 135 : baseMaxWidth;

  // Render top banner if "creative"
  if (style === "creative") {
    // Top primary header banner
    doc.setFillColor(primaryColor);
    doc.rect(0, 0, pgWidth, 42, "F");
    
    // Set custom white theme color for header text
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(22);
    doc.setTextColor("#ffffff");
    const fullNameSplitted = doc.splitTextToSize((cv.fullName || "JASUR ALIMOV").toUpperCase(), headerTextMaxWidth);
    doc.text(fullNameSplitted, lMargin, 16);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor("#ffffff");
    const contactText = `${cv.location || "Toshkent, O'zbekiston"}  |  ${cv.phone || "+998 (90) 123-45-67"} ${cv.email ? ` |  ${cv.email}` : ''}`;
    const contactSplitted = doc.splitTextToSize(contactText, headerTextMaxWidth);
    doc.text(contactSplitted, lMargin, 26);
    
    yVal = 48;

    // Creative circular / square photo
    if (cv.picture) {
      try {
        const format = cv.picture.includes("png") ? "PNG" : "JPEG";
        // Let's place it at right margin inside the banner with white border
        doc.setFillColor("#ffffff");
        doc.rect(pgWidth - lMargin - 26, 8, 26, 26, "F");
        doc.addImage(cv.picture, format, pgWidth - lMargin - 25, 9, 24, 24);
      } catch (e) {
        console.warn("Creative photo render failed in PDF", e);
      }
    }
  } else if (style === "modern") {
    // Modern: Side vertical colored accent strip, and wide layout
    doc.setFillColor(primaryColor);
    doc.rect(0, 0, 6, 297, "F"); // 6mm thick vertical left stripe
    
    // Shift left margin slightly to protect from stripe
    const sideMargin = 18;
    
    // Render profile photo if present
    if (cv.picture) {
      try {
        const format = cv.picture.includes("png") ? "PNG" : "JPEG";
        doc.addImage(cv.picture, format, 170 - 15, 15, 25, 25);
        // Clean modern border
        doc.setDrawColor(primaryColor);
        doc.setLineWidth(0.4);
        doc.rect(170 - 15, 15, 25, 25);
      } catch (e) {}
    }

    doc.setFont("Helvetica", "bold");
    doc.setFontSize(23);
    doc.setTextColor(primaryColor);
    const fullNameSplitted = doc.splitTextToSize((cv.fullName || "JASUR ALIMOV").toUpperCase(), cv.picture ? 130 : 170);
    doc.text(fullNameSplitted, sideMargin, yVal);
    yVal += (fullNameSplitted.length * 8.5);

    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor(secondaryColor);
    const contactText = `${cv.location || "Toshkent, O'zbekiston"}  |  ${cv.phone || "+998 (90) 123-45-67"} ${cv.email ? ` |  ${cv.email}` : ''}`;
    doc.text(contactText, sideMargin, yVal);
    yVal += 8;

    if (cv.picture) {
      yVal = Math.max(yVal, 46);
    }

    // Modern colored rule under header
    doc.setDrawColor(primaryColor);
    doc.setLineWidth(0.5);
    doc.line(sideMargin, yVal, pgWidth - lMargin, yVal);
    yVal += 8;

  } else if (style === "minimal") {
    // Minimalist: centered clean elegant header, no background boxes, generous white borders
    if (cv.picture) {
      try {
        const format = cv.picture.includes("png") ? "PNG" : "JPEG";
        // center image
        doc.addImage(cv.picture, format, (pgWidth - 22) / 2, 12, 22, 22);
        yVal = 40;
      } catch (e) {}
    }

    doc.setFont("Helvetica", "bold");
    doc.setFontSize(21);
    doc.setTextColor("#1e293b"); // Slate 800
    const fullNameSplitted = doc.splitTextToSize((cv.fullName || "JASUR ALIMOV").toUpperCase(), baseMaxWidth);
    doc.text(fullNameSplitted, pgWidth / 2, yVal, { align: "center" });
    yVal += (fullNameSplitted.length * 8);

    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor("#64748b"); // Slate 500
    const contactText = `${cv.location || "Toshkent, O'zbekiston"}  •  ${cv.phone || "+998 (90) 123-45-67"} ${cv.email ? `  •  ${cv.email}` : ''}`;
    doc.text(contactText, pgWidth / 2, yVal, { align: "center" });
    yVal += 10;
  } else {
    // Classic: our traditional solid left-aligned layout
    if (cv.picture) {
      try {
        const format = cv.picture.includes("png") ? "PNG" : "JPEG";
        doc.addImage(cv.picture, format, 170 - 15, 15, 25, 25);
        doc.setDrawColor("#cbd5e1");
        doc.setLineWidth(0.25);
        doc.rect(170 - 15, 15, 25, 25);
      } catch (e) {}
    }

    doc.setFont("Helvetica", "bold");
    doc.setFontSize(22);
    doc.setTextColor(primaryColor);
    const fullNameSplitted = doc.splitTextToSize((cv.fullName || "JASUR ALIMOV").toUpperCase(), headerTextMaxWidth);
    doc.text(fullNameSplitted, lMargin, yVal);
    yVal += (fullNameSplitted.length * 8.5);

    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor(secondaryColor);
    const contactText = `${cv.location || "Toshkent, O'zbekiston"}  |  ${cv.phone || "+998 (90) 123-45-67"} ${cv.email ? ` |  ${cv.email}` : ''}`;
    const contactSplitted = doc.splitTextToSize(contactText, headerTextMaxWidth);
    doc.text(contactSplitted, lMargin, yVal);
    yVal += (contactSplitted.length * 5) + 2;

    if (cv.picture) {
      yVal = Math.max(yVal, 44);
    }

    doc.setDrawColor(primaryColor);
    doc.setLineWidth(0.4);
    doc.line(lMargin, yVal, pgWidth - lMargin, yVal);
    yVal += 8;
  }

  const currentMargin = style === "modern" ? 18 : 15;
  const maxTextWidth = pgWidth - currentMargin - lMargin;

  // A helper to draw section headers styled appropriately
  const drawSectionHeader = (title: string, yPos: number): number => {
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(10.5);

    if (style === "creative") {
      // Solid rectangle with white text
      doc.setFillColor(primaryColor);
      doc.rect(currentMargin, yPos - 4.5, pgWidth - currentMargin - lMargin, 6.5, "F");
      doc.setTextColor("#ffffff");
      doc.text(title, currentMargin + 3, yPos);
      return yPos + 6;
    } else if (style === "modern") {
      // Vertical left accent block
      doc.setFillColor(primaryColor);
      doc.rect(currentMargin, yPos - 4, 3.5, 5, "F");
      doc.setTextColor(primaryColor);
      doc.text(title, currentMargin + 6, yPos);
      return yPos + 5;
    } else if (style === "minimal") {
      // Clean underlined heading in gray-blue with spacing
      doc.setTextColor("#0f172a");
      doc.text(title, currentMargin, yPos);
      doc.setDrawColor("#f1f5f9");
      doc.setLineWidth(0.5);
      doc.line(currentMargin, yPos + 1.5, pgWidth - lMargin, yPos + 1.5);
      return yPos + 6;
    } else {
      // Classic
      doc.setTextColor(primaryColor);
      doc.text(title, currentMargin, yPos);
      doc.setDrawColor(primaryColor);
      doc.setLineWidth(0.25);
      doc.line(currentMargin, yPos + 1.5, pgWidth - lMargin, yPos + 1.5);
      return yPos + 6;
    }
  };

  // 1. Professional summary
  if (cv.summary) {
    if (yVal > 265) { doc.addPage(); yVal = 20; }
    yVal = drawSectionHeader("PROFESSIONAL SUMMARY", yVal);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor("#334155");
    const splitSummary = doc.splitTextToSize(cv.summary, maxTextWidth);
    doc.text(splitSummary, currentMargin, yVal);
    yVal += splitSummary.length * 4.5 + 5;
  }

  // 2. Core Skills
  if (cv.skills && cv.skills.length > 0) {
    if (yVal > 265) { doc.addPage(); yVal = 20; }
    yVal = drawSectionHeader("TECHNICAL AND SOFT SKILLS", yVal);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor("#334155");
    const skillsText = cv.skills.join("  •  ");
    const splitSkills = doc.splitTextToSize(skillsText, maxTextWidth);
    doc.text(splitSkills, currentMargin, yVal);
    yVal += splitSkills.length * 4.5 + 7;
  }

  // 3. Work Experience / Professional History
  if (cv.experience && cv.experience.length > 0) {
    if (yVal > 265) { doc.addPage(); yVal = 20; }
    yVal = drawSectionHeader("WORK EXPERIENCE", yVal);
    
    cv.experience.forEach((exp) => {
      if (yVal > 255) {
        doc.addPage();
        yVal = 20;
      }

      // Company and Date
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(10.5);
      doc.setTextColor("#0f172a");
      doc.text(exp.company || "Yashirin korxona", currentMargin, yVal);
      
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(9);
      doc.setTextColor(secondaryColor);
      doc.text(exp.duration || "Faol", pgWidth - lMargin, yVal, { align: "right" });
      yVal += 4.5;

      // Position
      doc.setFont("Helvetica", "oblique");
      doc.setFontSize(10);
      doc.setTextColor(primaryColor);
      doc.text(exp.position || "Kandidat", currentMargin, yVal);
      yVal += 4.5;

      // Description Bullet Points
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(9.5);
      doc.setTextColor("#475569");
      const splitDesc = doc.splitTextToSize(exp.description || "", maxTextWidth - 4);
      
      splitDesc.forEach((line: string) => {
        if (yVal > 275) {
          doc.addPage();
          yVal = 20;
        }
        doc.text("• " + line, currentMargin + 2, yVal);
        yVal += 4.2;
      });
      yVal += 4;
    });
  }

  // 4. Education
  if (cv.education) {
    if (yVal > 260) {
      doc.addPage();
      yVal = 20;
    }
    yVal = drawSectionHeader("EDUCATION AND QUALIFICATIONS", yVal);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor("#334155");
    const splitEd = doc.splitTextToSize(cv.education, maxTextWidth);
    doc.text(splitEd, currentMargin, yVal);
    yVal += splitEd.length * 4.5 + 6;
  }

  // 5. Languages
  if (cv.languages && cv.languages.length > 0) {
    if (yVal > 260) {
      doc.addPage();
      yVal = 20;
    }
    yVal = drawSectionHeader("LANGUAGES", yVal);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor("#334155");
    const langString = cv.languages.map(l => `${l.language} (${l.level})`).join("   |   ");
    doc.text(langString, currentMargin, yVal);
    yVal += 7;
  }

  // Thin professional footer signature
  if (yVal < 275) {
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor("#94a3b8");
    doc.text(`Sertifikatlangan ATS-Friendly ${style.toUpperCase()} shakl  |  Yaratilgan vaqt: ` + new Date().toLocaleDateString() + "  |  Powered by ResumeAI UZ Telegram Bot", pgWidth / 2, 287, { align: "center" });
  }

  const cleanName = (cv.fullName || "CV").replace(/\s+/g, '_');
  doc.save(`${cleanName}_ResumeAI_UZ_${style}.pdf`);
}
