import React, { useState, useEffect, useRef } from "react";
import { 
  Bot, 
  FileText, 
  Briefcase, 
  Award, 
  CheckCircle, 
  CreditCard, 
  Send, 
  Sparkles, 
  RefreshCw, 
  AlertCircle, 
  Trash, 
  Download, 
  ArrowRight, 
  User, 
  Phone, 
  BookOpen, 
  Languages, 
  MapPin, 
  Search, 
  HelpCircle,
  TrendingUp,
  FileCheck,
  Check,
  Star,
  Sparkle
} from "lucide-react";
import { CVData, JobVacancy, InterviewPrep } from "./types";
import TelegramChat, { ChatMessage } from "./components/TelegramChat";
import MiniAppBuilder from "./components/MiniAppBuilder";
import MiniAppPaperPreview from "./components/MiniAppPaperPreview";
import MiniAppJobs from "./components/MiniAppJobs";
import MiniAppAssistants from "./components/MiniAppAssistants";
import MiniAppBilling from "./components/MiniAppBilling";

// Universal API fetch client supporting cross-origin Netlify hosting if needed
const apiFetch = (url: string, options?: RequestInit) => {
  const backendUrl = (import.meta as any).env.VITE_BACKEND_URL || "";
  const targetUrl = url.startsWith("/") ? `${backendUrl}${url}` : `${backendUrl}/${url}`;
  return fetch(targetUrl, options);
};

export default function App() {
  // Navigation & UI States
  const [activeTab, setActiveTab ] = useState<"bot" | "builder" | "jobs" | "assistants" | "billing">("builder");
  const [isPremium, setIsPremium] = useState<boolean>(false);
  const [mobileNavMode, setMobileNavMode] = useState<"chat" | "webapp">("webapp");
  const [cvBuilderStep, setCvBuilderStep] = useState<number>(1);
  const [showMiniAppCvPreview, setShowMiniAppCvPreview ] = useState<boolean>(false);
  const [activeChatId, setActiveChatId] = useState<string>("bot");
  const [digitalTime, setDigitalTime] = useState("09:41");

  // Dynamic ticking clock simulation
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setDigitalTime(
        now.toLocaleTimeString("uz-UZ", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Bot Connection Status
  const [botStatus, setBotStatus] = useState({
    botName: "ResumeAI UZ Bot",
    isBotActive: false,
    botTokenSupplied: false,
    appUrl: "",
    geminiStatus: "CONFIGURED"
  });

  useEffect(() => {
    apiFetch("/api/bot-status")
      .then(res => res.json())
      .then(data => {
        setBotStatus(data);
      })
      .catch(err => console.error("Error fetching bot status:", err));

    // Initialize actual Telegram WebApp environment
    try {
      const tg = (window as any).Telegram?.WebApp;
      if (tg) {
        tg.ready();
        tg.expand();
        // Set header color matching the current dark theme bar
        if (tg.setHeaderColor) {
          tg.setHeaderColor("#17212b");
        }
      }
    } catch (e) {
      console.warn("Telegram WebApp API error:", e);
    }
  }, []);

  // ==========================================
  // STATE 1: Telegram Bot Simulator Chat
  // ==========================================
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "bot",
      text: "Asalomu alaykum! 🤖\n\nMen **ResumeAI UZ** botiman. Sizga professional CV/Rezyume yaratishda, asosiy xatolarni tuzatishda, to'g'ri vakansiya topishda va suhbatga tayyorlanishda ko'maklashaman!\n\nAsosiy bo'limlarni boshqarish uchun quyidagi klaviaturani bosing yoki xabar matnini yozib yuboring:",
      replyMarkup: [
        ["📄 Yangi CV yaratish (AI)", "✨ CVni yaxshilash (AI)"],
        ["💼 Ishlar ro'yxati", "💡 Suhbatga tayyorgarlik"],
        ["✉️ Kuzatuv xati (AI Cover Letter)", "💳 Premium & To'lov"],
        ["🇺🇿/🇬🇧 Tilni almashtirish"]
      ]
    }
  ]);
  const [userInput, setUserInput] = useState("");
  const [isSimulatingTyping, setIsSimulatingTyping] = useState(false);

  // Send message controller
  const handleSendSimulatedMessage = async (messageText: string) => {
    if (!messageText.trim()) return;

    // Fast routing states for inline mini app integration
    if (messageText.includes("Yangi CV")) {
      setActiveTab("builder");
      setMobileNavMode("webapp");
      setCvBuilderStep(1);
    } else if (messageText.includes("CVni yaxshilash") || messageText.includes("yaxshilash")) {
      setActiveTab("assistants");
      setActiveSubAgent("interview");
      setMobileNavMode("webapp");
    } else if (messageText.includes("Ishlar ro'yxati") || messageText.includes("Bo'sh ish o'rinlari") || messageText.includes("Ish qidirish")) {
      setActiveTab("jobs");
      setMobileNavMode("webapp");
    } else if (messageText.includes("Suhbatga tayyorgarlik") || messageText.includes("Suhbat")) {
      setActiveTab("assistants");
      setActiveSubAgent("interview");
      setMobileNavMode("webapp");
    } else if (messageText.includes("Kuzatuv xati") || messageText.includes("Cover Letter")) {
      setActiveTab("assistants");
      setActiveSubAgent("cover");
      setMobileNavMode("webapp");
    } else if (messageText.includes("Premium") || messageText.includes("To'lov")) {
      setActiveTab("billing");
      setMobileNavMode("webapp");
    }

    // Intercept vacacies redirection
    if (messageText.includes("Ishlar ro'yxati") || messageText.includes("Bo'sh ish o'rinlari")) {
      const userMsgId = Date.now().toString();
      const newUserMessage: ChatMessage = {
        id: userMsgId,
        sender: "user",
        text: messageText
      };
      const botReplyMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "bot",
        text: "Siz Telegram dagi **@bobo_vakansiya** kanaliga yo'naltirilmoqdasiz...\n\nAgarda kanal avtomatik ochilmagan bo'lsa, ushbu havola orqali o'ting: https://t.me/bobo_vakansiya",
        replyMarkup: [
          ["📄 Yangi CV yaratish (AI)", "✨ CVni yaxshilash (AI)"],
          ["💼 Ishlar ro'yxati", "💡 Suhbatga tayyorgarlik"],
          ["✉️ Kuzatuv xati (AI Cover Letter)", "💳 Premium & To'lov"],
          ["🇺🇿/🇬🇧 Tilni almashtirish"]
        ]
      };
      setChatHistory(prev => [...prev, newUserMessage, botReplyMsg]);
      setUserInput("");
      return;
    }

    const userMsgId = Date.now().toString();
    const newUserMessage: ChatMessage = {
      id: userMsgId,
      sender: "user",
      text: messageText
    };
    setChatHistory(prev => [...prev, newUserMessage]);
    setUserInput("");
    setIsSimulatingTyping(true);

    try {
      const response = await apiFetch("/api/bot-simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "web-simulator-user-12345",
          username: "Kandidat_AI",
          text: messageText
        })
      });
      const data = await response.json();
      setIsSimulatingTyping(false);

      if (data.success && data.reply) {
        if (data.reply.cvData) {
          setCvForm(data.reply.cvData);
          if (data.reply.cvData.skills) {
            setRawSkillInput(data.reply.cvData.skills.join(", "));
          }
        }

        setChatHistory(prev => [...prev, {
          id: Date.now().toString() + "-reply",
          sender: "bot",
          text: data.reply.text,
          replyMarkup: data.reply.replyKeyboard,
          inlineButtons: data.reply.inlineKeyboard,
          documentUrl: data.reply.documentUrl,
          cvCreated: data.reply.cvData
        }]);

        if (data.session && data.session.isPremium) {
          setIsPremium(true);
        }
      } else {
        throw new Error("Invalid response");
      }
    } catch (error) {
      setIsSimulatingTyping(false);
      setChatHistory(prev => [...prev, {
        id: Date.now().toString() + "-error",
        sender: "bot",
        text: "Kechirasiz, tarmoq xatoligi yuz berdi. Bot bilan bog'lanishda muammo bo'ldi."
      }]);
    }
  };

  const handleResetChat = () => {
    setChatHistory([
      {
        id: "welcome-reset",
        sender: "bot",
        text: "Bo't yangitdan ishga tushirildi! Qaysi amaliyotni bajarishni istaysiz? 😊",
        replyMarkup: [
          ["📄 Yangi CV yaratish (AI)", "✨ CVni yaxshilash (AI)"],
          ["💼 Ishlar ro'yxati", "💡 Suhbatga tayyorgarlik"],
          ["✉️ Kuzatuv xati (AI Cover Letter)", "💳 Premium & To'lov"],
          ["🇺🇿/🇬🇧 Tilni almashtirish"]
        ]
      }
    ]);
  };

  // ==========================================
  // STATE 2: Web Form CV Builder
  // ==========================================
  const [cvForm, setCvForm] = useState<CVData>({
    fullName: "",
    phone: "",
    email: "",
    location: "Toshkent, O'zbekiston",
    education: "",
    skills: [],
    experience: [
      { company: "", position: "", duration: "", description: "" }
    ],
    languages: [
      { language: "O'zbek tili", level: "Mukammal" }
    ],
    summary: ""
  });

  const [rawSkillInput, setRawSkillInput] = useState("");
  const [isGeneratingCV, setIsGeneratingCV] = useState(false);
  const [themeColor, setThemeColor] = useState("#1e293b"); // default slate

  const addExperienceField = () => {
    setCvForm(prev => ({
      ...prev,
      experience: [...prev.experience, { company: "", position: "", duration: "", description: "" }]
    }));
  };

  const removeExperienceField = (index: number) => {
    setCvForm(prev => ({
      ...prev,
      experience: prev.experience.filter((_, i) => i !== index)
    }));
  };

  const handleExperienceChange = (index: number, field: string, value: string) => {
    const updated = [...cvForm.experience];
    updated[index] = { ...updated[index], [field]: value };
    setCvForm(prev => ({ ...prev, experience: updated }));
  };

  const addLanguageField = () => {
    setCvForm(prev => ({
      ...prev,
      languages: [...prev.languages, { language: "Ingliz tili", level: "O'rtacha" }]
    }));
  };

  const removeLanguageField = (index: number) => {
    setCvForm(prev => ({
      ...prev,
      languages: prev.languages.filter((_, i) => i !== index)
    }));
  };

  const handleLanguageChange = (index: number, field: string, value: string) => {
    const updated = [...cvForm.languages];
    updated[index] = { ...updated[index], [field]: value };
    setCvForm(prev => ({ ...prev, languages: updated }));
  };

  // Build optimized CV layout via backend Node-Gemini AI
  const handleBuildAICVWeb = async () => {
    if (!cvForm.fullName || !cvForm.phone) {
      alert("Iltimos, Ism va Telefon raqamingizni kiriting!");
      return;
    }

    setIsGeneratingCV(true);
    try {
      const skillsArray = rawSkillInput
        ? rawSkillInput.split(",").map(s => s.trim()).filter(Boolean)
        : cvForm.skills;

      const response = await apiFetch("/api/cv/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cvData: { ...cvForm, skills: skillsArray },
          targetLang: "uz"
        })
      });
      const data = await response.json();
      if (data.success && data.cv) {
        setCvForm(data.cv);
        setRawSkillInput(data.cv.skills.join(", "));
        alert("Tabriklaymiz! AI rezyumeingizni professional darajaga o'tkazdi va eng yaxshi ATS jumlalarini shakllantirdi! 💎");
      }
    } catch (err) {
      console.error(err);
      alert("AI CV shakllantirishda xatolik yuz berdi.");
    } finally {
      setIsGeneratingCV(false);
    }
  };

  // ==========================================
  // STATE 3: Viral "Before vs After" Review Tool
  // ==========================================
  const [beforeText, setBeforeText] = useState("");
  const [afterAnalysis, setAfterAnalysis] = useState(null);
  const [isImprovingRaw, setIsImprovingRaw] = useState(false);

  const handleImproveRawCV = async () => {
    if (!beforeText.trim()) return;
    setIsImprovingRaw(true);
    try {
      const response = await apiFetch("/api/cv/improve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawText: beforeText })
      });
      const data = await response.json();
      if (data.success && data.analysis) {
        setAfterAnalysis(data.analysis);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsImprovingRaw(false);
    }
  };

  // ==========================================
  // STATE 4: Jobs Finder & AI Suitability Matching
  // ==========================================
  const [jobs, setJobs] = useState<JobVacancy[]>([]);
  const [activeCategory, setActiveCategory ] = useState<string>("all");
  const [activeLocation, setActiveLocation ] = useState<string>("all");
  const [isLoadingJobs, setIsLoadingJobs] = useState(false);
  const [selectedJobForMatch, setSelectedJobForMatch ] = useState<JobVacancy | null>(null);
  const [matchScore, setMatchScore ] = useState<number | null>(null);
  const [matchReport, setMatchReport ] = useState<string>("");
  const [isCalculatingMatch, setIsCalculatingMatch] = useState(false);

  const fetchJobs = () => {
    setIsLoadingJobs(true);
    apiFetch(`/api/jobs?category=${activeCategory}&location=${activeLocation}`)
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setJobs(data.jobs);
        }
      })
      .catch(err => console.error(err))
      .finally(() => setIsLoadingJobs(false));
  };

  useEffect(() => {
    fetchJobs();
  }, [activeCategory, activeLocation]);

  const handleTestAICVMatch = async (job: JobVacancy) => {
    setSelectedJobForMatch(job);
    setIsCalculatingMatch(true);
    setMatchScore(null);

    // AI calculations - semantic simulation
    setTimeout(() => {
      let count = 0;
      const combinedTxt = (cvForm.fullName + " " + cvForm.education + " " + (cvForm.skills || []).join(" ")).toLowerCase();
      job.requirements.forEach(req => {
        const words = req.toLowerCase().replace(/[.,;]/g, '').split(" ");
        words.forEach(w => {
          if (w.length > 3 && combinedTxt.includes(w)) {
            count++;
          }
        });
      });

      const calculatedScore = Math.min(95, 55 + count * 10);
      setMatchScore(calculatedScore);

      let reportText = "";
      if (calculatedScore >= 75) {
        reportText = `Sizning rezyumeingiz ushbu bo'sh ish o'rniga juda munosib! AI tizimi quyidagilarni aniqladi:\n\n✨ SIZNING USTUNLIGINGIZ: Sizning ushbu yo'nalish bo'yicha shakllantirilgan ko'nikmalaringiz (${(cvForm.skills || []).join(", ") || 'Kandidat'}) talab etilayotgan tajribaga mos tushmoqda.\n\nTAVSIYA: Kundalik rezyumelar bilan unumli muvaffaqiyat qozonish uchun pastdagi bog'lanish tugmasi orqali HR darsligiga yuborishingiz mumkin.`;
      } else {
        reportText = `Rezyumeingizda kichik o'sish imkoniyatlari mavjud. Tizim quyidagi professional tavsiyalarini taklif etadi:\n\n💡 QO'SHISH LOZIM KO'NIKMALAR: Ushbu lavozim uchun "${job.requirements.slice(0, 2).join(' hamda ')}" bilimlariga ega bo'lish muhim ahamiyat kasb etadi.\n\nYechim: CV Yozish bo'limiga o'tib, ko'nikmalar ro'yxatiga shu kalit so'zlarni bajonidil kiriting va qaytadan tekshirib ko'ring!`;
      }
      setMatchReport(reportText);
      setIsCalculatingMatch(false);
    }, 1500);
  };

  // ==========================================
  // STATE 5: AI Assistants (Interview & Cover Letter)
  // ==========================================
  const [activeSubAgent, setActiveSubAgent ] = useState<"interview" | "cover">("interview");
  const [selectedJobRole, setSelectedJobRole] = useState("Sales Specialist (Sotuvchi mudir)");
  const [interviewPrepData, setInterviewPrepData] = useState<InterviewPrep | null>(null);
  const [isGeneratingPrep, setIsGeneratingPrep] = useState(false);

  const handleGenerateInterviewQA = async () => {
    setIsGeneratingPrep(true);
    try {
      const response = await apiFetch("/api/interview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobType: selectedJobRole })
      });
      const data = await response.json();
      if (data.success && data.exam) {
        setInterviewPrepData(data.exam);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingPrep(false);
    }
  };

  const [jobCoverLetterDesc, setJobCoverLetterDesc] = useState("Sotuv bo'limi mudiri, Toshkent Korzinka do'koni");
  const [generatedLetter, setGeneratedLetter] = useState("");
  const [isGeneratingLetter, setIsGeneratingLetter] = useState(false);

  const handleGenerateLetter = async () => {
    setIsGeneratingLetter(true);
    try {
      const response = await apiFetch("/api/cover-letter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cvData: cvForm,
          jobDescription: jobCoverLetterDesc,
          targetLang: "uz"
        })
      });
      const data = await response.json();
      if (data.success && data.coverLetter) {
        setGeneratedLetter(data.coverLetter);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingLetter(false);
    }
  };

  // ==========================================
  // STATE 6: Monetization (Mock Pay)
  // ==========================================
  const [isPayingSim, setIsPayingSim] = useState<string | null>(null);
  
  const handleSimulatePayment = (method: string) => {
    setIsPayingSim(method);
    
    setTimeout(() => {
      apiFetch("/api/payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: method,
          amount: 29000,
          userId: "web-simulator-user-12345"
        })
      })
        .then(res => res.json())
        .then(data => {
          setIsPayingSim(null);
          if (data.success) {
            setIsPremium(true);
            alert(`🎉 Premium xususiyatlari faollashtirildi! Cheksiz AI yaratish va premium A4 shablonlarni yuklash imkoniyatiga ega bo'ldingiz.`);
          }
        });
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#0e1621] text-slate-100 flex flex-col font-sans select-none selection:bg-blue-600 selection:text-white relative overflow-x-hidden" id="main_wrapper">
      
      {/* 🚀 GLOWING AMBIENT BACKGROUNDS */}
      <div className="absolute top-1/4 left-1/4 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-blue-600/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-indigo-600/5 blur-[120px] pointer-events-none" />

      {/* 💻 TMA UPPER BOT HEADER BAR */}
      <header className="bg-[#17212b] border-b border-[#101921] px-5 py-4 shrink-0 shadow-md select-none sticky top-0 z-50">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="p-1 px-2.5 bg-blue-600 text-[10px] uppercase font-bold text-white rounded-lg flex items-center gap-1 shrink-0 shadow-sm font-mono tracking-widest">
              ResumeAI UZ 🛡️
            </span>
            <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#5288c1] font-mono hidden sm:inline">
              Bot Engine: ACTIVE
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-xs text-slate-300 font-sans font-medium">
              <span>Xizmat:</span>
              <span className="font-extrabold text-[#5288c1] font-sans">Telegram Mini App</span>
            </div>
            {isPremium ? (
              <span className="px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/15 text-amber-500 text-[9px] font-black uppercase tracking-widest rounded-lg flex items-center gap-1 font-mono border border-amber-500/30">
                <Star className="w-3 h-3 fill-amber-500" /> Premium VIP
              </span>
            ) : (
              <button 
                onClick={() => {
                  setActiveTab("billing");
                }}
                className="px-2.5 py-1 bg-blue-500 hover:bg-blue-600 text-white text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all cursor-pointer"
              >
                VIP ga o'tish
              </button>
            )}
          </div>
        </div>
      </header>

      {/* 🛠️ CORE WORKSPACE */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-4 md:p-6 overflow-hidden flex flex-col justify-stretch items-stretch min-h-[500px]" id="core_main">
        
        {/* Dynamic header navigation inside the mini app view */}
        <div className="relative shrink-0 bg-[#17212b] border border-[#101921] px-4 py-3 rounded-t-2xl text-left flex items-center justify-between z-30 shadow-sm" id="tma_top_bar">
          <div className="flex items-center gap-1.5 flex-1 min-w-0">
            <button 
              onClick={() => {
                if (showMiniAppCvPreview) {
                  setShowMiniAppCvPreview(false);
                } else if (cvBuilderStep > 1) {
                  setCvBuilderStep(prev => prev - 1);
                }
              }}
              className={`p-1 text-slate-400 hover:text-white rounded-full hover:bg-white/5 transition-all mr-0.5 ${
                (activeTab === "builder" && cvBuilderStep > 1) || (activeTab === "builder" && showMiniAppCvPreview) ? "visible" : "invisible w-0"
              }`}
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
            </button>
            <div className="min-w-0">
              <h3 className="text-[12.5px] font-black text-white truncate flex items-center gap-1 leading-tight select-text select-none">
                {activeTab === "builder" ? "ResumeAI UZ 📄" : activeTab === "assistants" ? "AI Maslahatchi 💡" : "Premium VIP Bo'limi 💎"}
              </h3>
              <p className="text-[9.5px] text-[#5288c1] font-bold leading-none select-none mt-0.5">@resume_ai_uz_bot • WebApp</p>
            </div>
          </div>

          {/* Webapp control icons */}
          <div className="flex items-center gap-3 select-none">
            <button 
              type="button"
              onClick={() => {
                // refresh trigger
                const btn = document.getElementById("tma_reload_icon");
                btn?.classList.add("animate-spin");
                setTimeout(() => btn?.classList.remove("animate-spin"), 800);
              }}
              className="text-slate-400 hover:text-white cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" id="tma_reload_icon" />
            </button>
          </div>
        </div>

        {/* Interactive Webapp Content pages viewport container */}
        <div className="flex-1 bg-slate-50 border-x border-[#101921] flex flex-col overflow-hidden relative z-20 min-h-0" id="tma_viewport">
          {activeTab === "builder" && (
            showMiniAppCvPreview ? (
              <MiniAppPaperPreview
                cvForm={cvForm}
                themeColor={themeColor}
                isGeneratingCV={isGeneratingCV}
                onClosePreview={() => setShowMiniAppCvPreview(false)}
              />
            ) : (
              <MiniAppBuilder
                cvForm={cvForm}
                setCvForm={setCvForm}
                themeColor={themeColor}
                setThemeColor={setThemeColor}
                rawSkillInput={rawSkillInput}
                setRawSkillInput={setRawSkillInput}
                isGeneratingCV={isGeneratingCV}
                handleBuildAICVWeb={handleBuildAICVWeb}
                addExperienceField={addExperienceField}
                removeExperienceField={removeExperienceField}
                handleExperienceChange={handleExperienceChange}
                addLanguageField={addLanguageField}
                removeLanguageField={removeLanguageField}
                handleLanguageChange={handleLanguageChange}
                cvBuilderStep={cvBuilderStep}
                setCvBuilderStep={setCvBuilderStep}
                setShowMiniAppCvPreview={setShowMiniAppCvPreview}
              />
            )
          )}

          {activeTab === "jobs" && (
            <div className="p-8 text-center text-slate-800">
              Ushbu bo'lim faqat Telegram kanalda mavjud.
            </div>
          )}

          {activeTab === "assistants" && (
            <MiniAppAssistants
              activeSubAgent={activeSubAgent}
              setActiveSubAgent={setActiveSubAgent}
              selectedJobRole={selectedJobRole}
              setSelectedJobRole={setSelectedJobRole}
              interviewPrepData={interviewPrepData}
              isGeneratingPrep={isGeneratingPrep}
              handleGenerateInterviewQA={handleGenerateInterviewQA}
              jobCoverLetterDesc={jobCoverLetterDesc}
              setJobCoverLetterDesc={setJobCoverLetterDesc}
              generatedLetter={generatedLetter}
              isGeneratingLetter={isGeneratingLetter}
              handleGenerateLetter={handleGenerateLetter}
            />
          )}

          {activeTab === "billing" && (
            <MiniAppBilling
              isPremium={isPremium}
              isPayingSim={isPayingSim}
              handleSimulatePayment={handleSimulatePayment}
            />
          )}
        </div>

        {/* Simulated Telegram Mini App Native Bottom Navigation Bar */}
        <div className="shrink-0 bg-white border border-[#101921] rounded-b-2xl py-1 px-2 flex items-center justify-around z-30 shadow-lg select-none" id="tma_bottom_nav">
          {[
            { id: "builder", label: "CV Yozish", icon: FileText },
            { id: "jobs", label: "Vakansiyalar", icon: Briefcase },
            { id: "assistants", label: "AI Maslahat", icon: Sparkles },
            { id: "billing", label: "Premium", icon: Star }
          ].map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.id === "jobs") {
                    window.open("https://t.me/bobo_vakansiya", "_blank");
                    return;
                  }
                  setActiveTab(item.id as any);
                  setShowMiniAppCvPreview(false);
                }}
                className={`flex-1 flex flex-col items-center justify-center py-2 px-3 rounded-xl transition-all cursor-pointer ${
                  isActive 
                    ? "text-[#2481cc] font-black scale-[1.03]" 
                    : "text-slate-400 hover:text-slate-600 font-medium"
                }`}
              >
                <item.icon className="w-5 h-5 mx-auto" />
                <span className="text-[10px] mt-1 font-sans tracking-tight block text-center">{item.label}</span>
              </button>
            );
          })}
        </div>

      </main>

      {/* 🔮 ARCHITECTURAL FOOTER */}
      <footer className="px-5 py-4 bg-[#17212b] border-t border-[#101921] select-none text-[8.5px] tracking-widest text-[#5288c1] font-extrabold uppercase shrink-0 flex flex-col sm:flex-row items-center justify-between gap-2.5">
        <div className="flex gap-4">
          <span>🇺🇿 O'zbekiston</span>
          <span>•</span>
          <span>ATS CERTIFIED PORTAL</span>
          <span>•</span>
          <span>FASTAPI CLOUD RUN BACKEND</span>
        </div>
        <div>
          ResumeAI UZ Inc © 2026. All Simulator Rights Reserved.
        </div>
      </footer>

    </div>
  );
}
